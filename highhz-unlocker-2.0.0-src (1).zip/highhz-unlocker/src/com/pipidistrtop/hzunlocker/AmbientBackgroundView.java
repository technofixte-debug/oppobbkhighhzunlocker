package com.pipidistrtop.hzunlocker;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.WindowManager;

/* loaded from: classes.dex */
public class AmbientBackgroundView extends View {
    private int currentTheme;
    private Paint paint1;
    private Paint paint2;
    private int primaryColor;
    private int secondaryColor;
    private int screenW;
    private int screenH;

    public AmbientBackgroundView(Context context) {
        super(context);
        this.paint1 = new Paint(1);
        this.paint2 = new Paint(1);
        this.primaryColor = 1426125055;
        this.secondaryColor = 1224671351;
        this.currentTheme = 0;
        captureScreenSize(context);
        updateThemeColors(ThemeManager.getTheme(context));
    }

    public void setScreenSize(int width, int height) {
        if (width > 0 && height > 0) {
            this.screenW = width;
            this.screenH = height;
            invalidate();
        }
    }

    private void captureScreenSize(Context context) {
        try {
            WindowManager windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
            if (windowManager != null && windowManager.getDefaultDisplay() != null) {
                DisplayMetrics metrics = new DisplayMetrics();
                windowManager.getDefaultDisplay().getRealMetrics(metrics);
                this.screenW = metrics.widthPixels;
                this.screenH = metrics.heightPixels;
            }
        } catch (Throwable ignored) {
        }
    }

    public void updateThemeColors(int i) {
        this.currentTheme = i;
        switch (i) {
            case 1:
                this.primaryColor = 1435025616;
                this.secondaryColor = 1147044268;
                break;
            case 2:
                this.primaryColor = 1488363000;
                this.secondaryColor = 1216105983;
                break;
            case ThemeManager.THEME_AMOLED_BLACK /* 3 */:
                this.primaryColor = 951295451;
                this.secondaryColor = 677799526;
                break;
            default:
                this.primaryColor = 1510011135;
                this.secondaryColor = 1308557431;
                break;
        }
        invalidate();
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int width = this.screenW > 0 ? this.screenW : getWidth();
        int height = this.screenH > 0 ? this.screenH : getHeight();
        if (width != 0 && height != 0) {
            long uptimeMillis = SystemClock.uptimeMillis();
            float f = ((uptimeMillis % 8000) / 8000.0f) * 6.2831855f;
            float sin = (width * 0.32f) + (((float) Math.sin(f)) * width * 0.28f);
            float cos = (height * 0.22f) + (((float) Math.cos(f)) * height * 0.14f);
            float f2 = 0.55f * width;
            this.paint1.setShader(new RadialGradient(sin, cos, f2, this.primaryColor, 0, Shader.TileMode.CLAMP));
            canvas.drawCircle(sin, cos, f2, this.paint1);
            float f3 = ((uptimeMillis % 11000) / 11000.0f) * 6.2831855f;
            float cos2 = (width * 0.72f) - (((float) Math.cos(f3)) * (width * 0.26f));
            float sin2 = (height * 0.68f) + (((float) Math.sin(f3)) * height * 0.16f);
            float f4 = 0.62f * width;
            this.paint2.setShader(new RadialGradient(cos2, sin2, f4, this.secondaryColor, 0, Shader.TileMode.CLAMP));
            canvas.drawCircle(cos2, sin2, f4, this.paint2);
            postInvalidateDelayed(16L);
        }
    }
}
