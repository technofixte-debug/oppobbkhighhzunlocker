package com.pipidistrtop.hzunlocker;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.hardware.display.DisplayManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;
import android.view.Display;
import android.view.WindowManager;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;

/* loaded from: classes.dex */
public class WatchdogService extends Service {
    private static final String CHANNEL_ID = "WatchdogServiceChannel";
    private static final int NOTIF_ID = 165;
    private static final String TAG = "WatchdogService";
    private static final long TICK_INTERVAL_MS = 1000;
    private DisplayManager.DisplayListener displayListener;
    private DisplayManager displayManager;
    private Handler handler;
    private BroadcastReceiver screenReceiver;
    private Runnable tickRunnable;
    public static volatile boolean isRunning = false;
    public static volatile long sLastRearmTime = 0;
    public static volatile long sRearmCount = 0;
    public static volatile String sLastRearmReason = "none";

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override // android.app.Service
    public void onCreate() {
        super.onCreate();
        this.handler = new Handler(Looper.getMainLooper());
        isRunning = true;
        try {
            this.displayManager = (DisplayManager) getSystemService("display");
            if (this.displayManager != null) {
                this.displayListener = new DisplayManager.DisplayListener() { // from class: com.pipidistrtop.hzunlocker.WatchdogService.1
                    @Override // android.hardware.display.DisplayManager.DisplayListener
                    public void onDisplayAdded(int i) {
                    }

                    @Override // android.hardware.display.DisplayManager.DisplayListener
                    public void onDisplayRemoved(int i) {
                    }

                    @Override // android.hardware.display.DisplayManager.DisplayListener
                    public void onDisplayChanged(int i) {
                        if (i == 0) {
                            WatchdogService.this.checkDisplayDropAndRearm("display");
                        }
                    }
                };
                this.displayManager.registerDisplayListener(this.displayListener, this.handler);
            }
        } catch (Throwable th) {
        }
        try {
            this.screenReceiver = new BroadcastReceiver() { // from class: com.pipidistrtop.hzunlocker.WatchdogService.2
                @Override // android.content.BroadcastReceiver
                public void onReceive(Context context, Intent intent) {
                    if (intent != null && "android.intent.action.SCREEN_ON".equals(intent.getAction())) {
                        WatchdogService.this.rearmAllVotes("screen");
                    }
                }
            };
            registerReceiver(this.screenReceiver, new IntentFilter("android.intent.action.SCREEN_ON"));
        } catch (Throwable th2) {
        }
    }

    @Override // android.app.Service
    public int onStartCommand(Intent intent, int i, int i2) {
        startForeground(NOTIF_ID, buildNotification(getString(R.string.notif_wd)));
        if (this.tickRunnable == null) {
            this.tickRunnable = new Runnable() { // from class: com.pipidistrtop.hzunlocker.WatchdogService.3
                @Override // java.lang.Runnable
                public void run() {
                    WatchdogService.this.rearmAllVotes("timer");
                    if (WatchdogService.isRunning && WatchdogService.this.handler != null) {
                        WatchdogService.this.handler.postDelayed(this, WatchdogService.TICK_INTERVAL_MS);
                    }
                }
            };
            this.handler.post(this.tickRunnable);
            return 1;
        }
        return 1;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void checkDisplayDropAndRearm(final String str) {
        float f;
        Display defaultDisplay;
        Display display;
        try {
            f = (this.displayManager == null || (display = this.displayManager.getDisplay(0)) == null) ? 0.0f : display.getRefreshRate();
        } catch (Throwable th) {
            f = 0.0f;
        }
        if (f <= 0.0f) {
            try {
                WindowManager windowManager = (WindowManager) getSystemService("window");
                f = (windowManager == null || (defaultDisplay = windowManager.getDefaultDisplay()) == null) ? f : defaultDisplay.getRefreshRate();
            } catch (Throwable th2) {
            }
        }
        final int round = Math.round(f);
        RateLock.sExecutor.execute(new Runnable() { // from class: com.pipidistrtop.hzunlocker.WatchdogService.4
            @Override // java.lang.Runnable
            public void run() {
                boolean dropped = false;
                SharedPreferences sharedPreferences = WatchdogService.this.getSharedPreferences("FpsPrefs", 0);
                Map<String, ?> all = sharedPreferences.getAll();
                for (String key : all.keySet()) {
                    if (key != null && key.startsWith("app_hz_") && Boolean.TRUE.equals(all.get(key))) {
                        if (round < RateLock.getAppRate(sharedPreferences, WatchdogService.this, key.substring("app_hz_".length()))) {
                            dropped = true;
                            break;
                        }
                    }
                }
                if (dropped) {
                    WatchdogService.this.rearmAllVotes(str);
                }
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public synchronized void rearmAllVotes(final String str) {
        long currentTimeMillis = System.currentTimeMillis();
        if ("timer".equals(str) || currentTimeMillis - sLastRearmTime >= 500) {
            RateLock.sExecutor.execute(new Runnable() { // from class: com.pipidistrtop.hzunlocker.WatchdogService.5
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        SharedPreferences sharedPreferences = WatchdogService.this.getSharedPreferences("FpsPrefs", 0);
                        boolean z = sharedPreferences.getBoolean("fps_enabled", false);
                        boolean z2 = sharedPreferences.getBoolean("watchdog_mode", false);
                        if (!z || !z2) {
                            WatchdogService.this.stopSelf();
                            return;
                        }
                        WatchdogService.sLastRearmTime = System.currentTimeMillis();
                        WatchdogService.sRearmCount++;
                        WatchdogService.sLastRearmReason = str;
                        Map<String, ?> all = sharedPreferences.getAll();
                        HashSet hashSet = new HashSet();
                        for (Map.Entry<String, ?> entry : all.entrySet()) {
                            String key = entry.getKey();
                            if (key != null && key.startsWith("app_hz_") && Boolean.TRUE.equals(entry.getValue())) {
                                String substring = key.substring("app_hz_".length());
                                hashSet.add(substring);
                                int hzToRateId = RateLock.hzToRateId(RateLock.getAppRate(sharedPreferences, WatchdogService.this, substring));
                                RateLock.recordPackageDiag(substring, hzToRateId, RateLock.arm(WatchdogService.this, substring, hzToRateId) ? 1 : 0, Oiface.registerGame(substring));
                            }
                        }
                        for (String str2 : RateLock.getArmedMap(WatchdogService.this).keySet()) {
                            if (!hashSet.contains(str2)) {
                                RateLock.arm(WatchdogService.this, str2, 0);
                                Oiface.unregisterGame(str2);
                                RateLock.removePackageDiag(str2);
                            }
                        }
                        RateLock.sArmedCount = hashSet.size();
                        WatchdogService.this.updateNotification(WatchdogService.this.getString(R.string.notif_wd_count, Integer.valueOf(hashSet.size())));
                    } catch (Throwable th) {
                        Log.e(WatchdogService.TAG, "rearmAllVotes error: " + th.getMessage());
                    }
                }
            });
        }
    }

    private Notification buildNotification(String str) {
        if (Build.VERSION.SDK_INT >= 26) {
            try {
                Notify.ensureChannel(this, CHANNEL_ID, getString(R.string.channel_wd));
                return new Notification.Builder(this, CHANNEL_ID)
                        .setContentTitle(getString(R.string.app_name))
                        .setContentText(str)
                        .setSmallIcon(R.drawable.ic_launcher)
                        .setContentIntent(PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), 67108864))
                        .build();
            } catch (Throwable ignored) {
            }
        }
        return new Notification();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateNotification(String str) {
        try {
            NotificationManager notificationManager = (NotificationManager) getSystemService("notification");
            if (notificationManager != null) {
                notificationManager.notify(NOTIF_ID, buildNotification(str));
            }
        } catch (Throwable th) {
        }
    }

    @Override // android.app.Service
    public void onTaskRemoved(Intent intent) {
        super.onTaskRemoved(intent);
        try {
            PendingIntent service = PendingIntent.getService(getApplicationContext(), 1, new Intent(getApplicationContext(), (Class<?>) WatchdogService.class), Build.VERSION.SDK_INT >= 23 ? 1140850688 : 1073741824);
            AlarmManager alarmManager = (AlarmManager) getSystemService("alarm");
            if (alarmManager != null) {
                alarmManager.set(0, System.currentTimeMillis() + TICK_INTERVAL_MS, service);
            }
        } catch (Throwable th) {
        }
    }

    @Override // android.app.Service
    public void onDestroy() {
        super.onDestroy();
        isRunning = false;
        if (this.handler != null && this.tickRunnable != null) {
            this.handler.removeCallbacks(this.tickRunnable);
        }
        if (this.displayManager != null && this.displayListener != null) {
            try {
                this.displayManager.unregisterDisplayListener(this.displayListener);
            } catch (Throwable th) {
            }
        }
        if (this.screenReceiver != null) {
            try {
                unregisterReceiver(this.screenReceiver);
            } catch (Throwable th2) {
            }
        }
        RateLock.sExecutor.execute(new Runnable() { // from class: com.pipidistrtop.hzunlocker.WatchdogService.6
            @Override // java.lang.Runnable
            public void run() {
                try {
                    RateLock.releaseAll(WatchdogService.this);
                    Oiface.unregisterAllOurGames();
                } catch (Throwable th3) {
                }
            }
        });
    }
}
