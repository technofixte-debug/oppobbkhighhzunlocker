package com.pipidistrtop.hzunlocker;

import android.os.IBinder;
import android.os.Parcel;
import android.util.Log;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

/* loaded from: classes.dex */
public class Oiface {
    public static final String IFACE = "com.oplus.oiface.IOIfaceService";
    public static final String SERVICE_NAME = "oplusoiface";
    private static final String TAG = "Oiface";
    private static final int TX_GET_INSTALLED_GAME_LIST = 1011;
    private static final int TX_SET_GAME_MODE_STATUS = 1007;
    private static final int TX_SET_INSTALLED_GAME_LIST = 1010;
    private static final Set<String> sOurRegistered = Collections.synchronizedSet(new HashSet());

    public static IBinder getService() {
        try {
            return (IBinder) Class.forName("android.os.ServiceManager").getMethod("getService", String.class).invoke(null, SERVICE_NAME);
        } catch (Throwable th) {
            return null;
        }
    }

    public static boolean isAvailable() {
        return getService() != null;
    }

    public static List<String> getInstalledGames() {
        String[] createStringArray = null;
        IBinder service = getService();
        if (service == null) {
            return Collections.emptyList();
        }
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        try {
            obtain.writeInterfaceToken(IFACE);
            service.transact(TX_GET_INSTALLED_GAME_LIST, obtain, obtain2, 0);
            obtain2.readException();
            createStringArray = obtain2.createStringArray();
        } catch (Throwable th) {
            Log.w(TAG, "getInstalledGames error: " + th.getMessage());
        } finally {
            obtain.recycle();
            obtain2.recycle();
        }
        return (createStringArray == null || createStringArray.length <= 0) ? Collections.emptyList() : new ArrayList(Arrays.asList(createStringArray));
    }

    public static boolean setInstalledGames(List<String> list) {
        IBinder service = getService();
        if (service == null) {
            return false;
        }
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        try {
            obtain.writeInterfaceToken(IFACE);
            obtain.writeStringArray(list != null ? (String[]) list.toArray(new String[0]) : new String[0]);
            service.transact(TX_SET_INSTALLED_GAME_LIST, obtain, obtain2, 0);
            obtain2.readException();
            return true;
        } catch (Throwable th) {
            Log.w(TAG, "setInstalledGames error: " + th.getMessage());
            return false;
        } finally {
            obtain.recycle();
            obtain2.recycle();
        }
    }

    public static boolean setGameMode(String str, boolean z) {
        IBinder service;
        if (str == null || str.isEmpty() || (service = getService()) == null) {
            return false;
        }
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        try {
            obtain.writeInterfaceToken(IFACE);
            obtain.writeInt(z ? 1 : 0);
            obtain.writeString(str);
            service.transact(TX_SET_GAME_MODE_STATUS, obtain, obtain2, 0);
            obtain2.readException();
            return true;
        } catch (Throwable th) {
            Log.w(TAG, "setGameMode error: " + th.getMessage());
            return false;
        } finally {
            obtain.recycle();
            obtain2.recycle();
        }
    }

    public static boolean registerGame(String str) {
        if (str == null || str.isEmpty() || !isAvailable()) {
            return false;
        }
        try {
            ArrayList arrayList = new ArrayList(getInstalledGames());
            if (arrayList.contains(str)) {
                setGameMode(str, true);
                sOurRegistered.add(str);
                return true;
            }
            arrayList.add(str);
            setInstalledGames(arrayList);
            boolean contains = getInstalledGames().contains(str);
            setGameMode(str, true);
            if (contains) {
                sOurRegistered.add(str);
            }
            return contains;
        } catch (Throwable th) {
            Log.w(TAG, "registerGame failed for " + str + ": " + th.getMessage());
            return false;
        }
    }

    public static boolean unregisterGame(String str) {
        if (str == null || str.isEmpty() || !isAvailable()) {
            return false;
        }
        try {
            ArrayList arrayList = new ArrayList(getInstalledGames());
            if (arrayList.contains(str)) {
                arrayList.remove(str);
                setInstalledGames(arrayList);
            }
            setGameMode(str, false);
            sOurRegistered.remove(str);
            return true;
        } catch (Throwable th) {
            Log.w(TAG, "unregisterGame failed for " + str + ": " + th.getMessage());
            return false;
        }
    }

    public static boolean isGameRegistered(String str) {
        if (str == null || str.isEmpty()) {
            return false;
        }
        try {
            return getInstalledGames().contains(str);
        } catch (Throwable th) {
            return false;
        }
    }

    public static void unregisterAllOurGames() {
        if (isAvailable()) {
            Iterator it = new ArrayList(sOurRegistered).iterator();
            while (it.hasNext()) {
                unregisterGame((String) it.next());
            }
            sOurRegistered.clear();
        }
    }
}
