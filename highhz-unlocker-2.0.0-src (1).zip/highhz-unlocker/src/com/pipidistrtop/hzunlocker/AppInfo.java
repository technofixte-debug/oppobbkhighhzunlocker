package com.pipidistrtop.hzunlocker;

/* loaded from: classes.dex */
public class AppInfo {
    public boolean enabled;
    public boolean isGame;
    public boolean isSystem;
    public String name;
    public String packageName;
    public int targetHz;

    public AppInfo(String str, String str2, boolean z, boolean z2, boolean z3, int i) {
        this.name = str;
        this.packageName = str2;
        this.isGame = z;
        this.isSystem = z2;
        this.enabled = z3;
        this.targetHz = i;
    }
}
