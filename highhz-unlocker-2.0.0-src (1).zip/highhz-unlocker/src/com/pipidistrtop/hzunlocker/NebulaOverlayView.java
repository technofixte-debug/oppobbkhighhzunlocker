package com.pipidistrtop.hzunlocker;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;

public class NebulaOverlayView extends View {
    private static final int NOISE_W = 192;
    private static final int NOISE_H = 320;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint paintFine = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Matrix matrix = new Matrix();
    private final Matrix matrixFine = new Matrix();
    private final int[] perm = new int[512];
    private Bitmap fog;
    private int bakedTheme = -2;
    private int theme = 3;
    private float phase;
    private boolean running;
    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!running || !isAttachedToWindow() || getVisibility() != VISIBLE) {
                running = false;
                return;
            }
            phase += 0.35f;
            invalidate();
            postDelayed(this, 48L);
        }
    };

    public NebulaOverlayView(Context context) {
        super(context);
        setWillNotDraw(false);
        setClickable(false);
        setFocusable(false);
        this.theme = ThemeManager.getTheme(context);
        int seed = 0x5F3759DF;
        for (int i = 0; i < 256; i++) {
            seed = seed * 1664525 + 1013904223;
            this.perm[i] = (seed >>> 24) & 255;
        }
        for (int i = 0; i < 256; i++) {
            this.perm[i + 256] = this.perm[i];
        }
    }

    public void setNebulaEnabled(boolean enabled) {
        setVisibility(enabled ? VISIBLE : GONE);
        if (enabled) {
            startDrift();
        } else {
            this.running = false;
            removeCallbacks(this.tick);
        }
    }

    public void updateTheme(int theme) {
        this.theme = theme;
        if (this.fog != null && this.bakedTheme != theme) {
            this.fog.recycle();
            this.fog = null;
        }
        invalidate();
    }

    private void startDrift() {
        if (this.running) {
            return;
        }
        this.running = true;
        removeCallbacks(this.tick);
        post(this.tick);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (getVisibility() == VISIBLE) {
            startDrift();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        this.running = false;
        removeCallbacks(this.tick);
        super.onDetachedFromWindow();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        return false;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int width = getWidth();
        int height = getHeight();
        if (width <= 0 || height <= 0) {
            return;
        }
        ensureFog(this.theme);
        if (this.fog == null) {
            return;
        }
        float driftX = this.phase * 0.55f;
        float driftY = this.phase * 0.32f;
        this.matrix.setScale(width / (float) NOISE_W * 1.35f, height / (float) NOISE_H * 1.35f);
        this.matrix.postTranslate(-driftX, -driftY);
        BitmapShader shader = new BitmapShader(this.fog, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT);
        shader.setLocalMatrix(this.matrix);
        this.paint.setShader(shader);
        this.paint.setAlpha(150);
        canvas.drawRect(0, 0, width, height, this.paint);

        this.matrixFine.setScale(width / (float) NOISE_W * 0.72f, height / (float) NOISE_H * 0.72f);
        this.matrixFine.postTranslate(driftX * 0.65f, driftY * 1.15f);
        BitmapShader fine = new BitmapShader(this.fog, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT);
        fine.setLocalMatrix(this.matrixFine);
        this.paintFine.setShader(fine);
        this.paintFine.setAlpha(90);
        canvas.drawRect(0, 0, width, height, this.paintFine);
    }

    private void ensureFog(int theme) {
        if (this.fog != null && this.bakedTheme == theme) {
            return;
        }
        int accent = ThemeManager.getAccentColor(theme);
        int ar = (accent >> 16) & 255;
        int ag = (accent >> 8) & 255;
        int ab = accent & 255;
        int[] pixels = new int[NOISE_W * NOISE_H];
        for (int y = 0; y < NOISE_H; y++) {
            for (int x = 0; x < NOISE_W; x++) {
                float n = fbm(x * 0.018f, y * 0.018f);
                float detail = fbm(x * 0.055f + 20f, y * 0.055f + 8f);
                float field = n * 0.72f + detail * 0.28f;
                float t = field * 0.5f + 0.5f;
                float wisp = Math.max(0f, t - 0.46f) / 0.54f;
                wisp = wisp * wisp;
                int alpha = (int) (wisp * 56f);
                int r = (232 * 4 + ar) / 5;
                int g = (236 * 4 + ag) / 5;
                int b = (242 * 4 + ab) / 5;
                pixels[y * NOISE_W + x] = (alpha << 24) | (r << 16) | (g << 8) | b;
            }
        }
        if (this.fog != null) {
            this.fog.recycle();
        }
        this.fog = Bitmap.createBitmap(pixels, NOISE_W, NOISE_H, Bitmap.Config.ARGB_8888);
        this.bakedTheme = theme;
    }

    private float fbm(float x, float y) {
        float sum = 0f;
        float amp = 0.5f;
        for (int i = 0; i < 5; i++) {
            sum += amp * noise(x, y);
            x = x * 2.02f + 1.7f;
            y = y * 2.02f + 0.9f;
            amp *= 0.5f;
        }
        return sum;
    }

    private float noise(float x, float y) {
        int x0 = floor(x);
        int y0 = floor(y);
        float tx = x - x0;
        float ty = y - y0;
        float u = fade(tx);
        float v = fade(ty);
        int aa = this.perm[(this.perm[x0 & 255] + y0) & 255];
        int ab = this.perm[(this.perm[x0 & 255] + y0 + 1) & 255];
        int ba = this.perm[(this.perm[(x0 + 1) & 255] + y0) & 255];
        int bb = this.perm[(this.perm[(x0 + 1) & 255] + y0 + 1) & 255];
        float x1 = lerp(grad(aa, tx, ty), grad(ba, tx - 1f, ty), u);
        float x2 = lerp(grad(ab, tx, ty - 1f), grad(bb, tx - 1f, ty - 1f), u);
        return lerp(x1, x2, v);
    }

    private static int floor(float value) {
        int i = (int) value;
        return value < i ? i - 1 : i;
    }

    private static float fade(float t) {
        return t * t * t * (t * (t * 6f - 15f) + 10f);
    }

    private static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    private static float grad(int hash, float x, float y) {
        switch (hash & 3) {
            case 0:
                return x + y;
            case 1:
                return -x + y;
            case 2:
                return x - y;
            default:
                return -x - y;
        }
    }
}
