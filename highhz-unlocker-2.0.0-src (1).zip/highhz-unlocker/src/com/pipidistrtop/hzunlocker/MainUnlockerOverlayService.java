package com.pipidistrtop.hzunlocker;

import android.app.Service;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Display;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

/**
 * Single overlay window.
 * overlay off + master on: tiny non-touchable window.
 * overlay on: the draggable refresh-rate counter.
 */
public class MainUnlockerOverlayService extends Service {
    private Handler handler;
    private boolean isViewAdded = false;
    private TextView overlayView;
    private WindowManager.LayoutParams params;
    private Runnable runnable;
    private WindowManager windowManager;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        RateLock.sOverlayServiceActive = true;
        this.windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        this.handler = new Handler(Looper.getMainLooper());
        setupOverlay();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        RateLock.sOverlayServiceActive = true;
        updateOverlayAppearance();
        return START_STICKY;
    }

    private void setupOverlay() {
        if (this.overlayView == null) {
            this.overlayView = new TextView(this);
            this.overlayView.setGravity(Gravity.CENTER);
        }
        int type = Build.VERSION.SDK_INT >= 26 ? 2038 : 2003;
        this.params = new WindowManager.LayoutParams(-2, -2, type, 40, -3);
        this.params.gravity = Gravity.TOP | Gravity.START;
        this.params.x = 60;
        this.params.y = 120;
        updateOverlayAppearance();
        if (this.runnable == null) {
            this.runnable = new Runnable() {
                @Override
                public void run() {
                    if (MainUnlockerOverlayService.this.getSharedPreferences("FpsPrefs", 0).getBoolean("overlay_enabled", false)
                            && MainUnlockerOverlayService.this.overlayView != null) {
                        MainUnlockerOverlayService.this.overlayView.setText(
                                MainUnlockerOverlayService.this.getString(R.string.fmt_hz, Integer.valueOf(getLiveHz())));
                        applyVisibleColors();
                    }
                    if (MainUnlockerOverlayService.this.handler != null) {
                        MainUnlockerOverlayService.this.handler.postDelayed(this, 1000L);
                    }
                }
            };
            this.handler.post(this.runnable);
        }
    }

    private void applyVisibleColors() {
        if (this.overlayView == null) {
            return;
        }
        int accent = ThemeManager.getAccentColor(ThemeManager.getTheme(this));
        int card = ThemeManager.getCardColor(ThemeManager.getTheme(this));
        this.overlayView.setTextColor(accent);
        GradientDrawable background = new GradientDrawable();
        background.setColor((card & 0x00FFFFFF) | 0xE6000000);
        background.setCornerRadius(30.0f);
        background.setStroke(dp(1), accent);
        this.overlayView.setBackground(background);
    }

    private void updateOverlayAppearance() {
        if (this.overlayView == null || this.params == null) {
            return;
        }
        boolean visible = getSharedPreferences("FpsPrefs", 0).getBoolean("overlay_enabled", false);
        RateLock.sOverlayVisibleMode = visible;
        if (visible) {
            this.params.width = WindowManager.LayoutParams.WRAP_CONTENT;
            this.params.height = WindowManager.LayoutParams.WRAP_CONTENT;
            this.params.flags = 40;
            this.overlayView.setPadding(24, 12, 24, 12);
            this.overlayView.setTextSize(13.0f);
            this.overlayView.setTypeface(null);
            this.overlayView.setText(getString(R.string.fmt_hz, Integer.valueOf(getLiveHz())));
            this.overlayView.setAlpha(1.0f);
            applyVisibleColors();
            this.overlayView.setOnTouchListener(new View.OnTouchListener() {
                private float initialTouchX;
                private float initialTouchY;
                private int initialX;
                private int initialY;

                @Override
                public boolean onTouch(View view, MotionEvent motionEvent) {
                    switch (motionEvent.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            this.initialX = MainUnlockerOverlayService.this.params.x;
                            this.initialY = MainUnlockerOverlayService.this.params.y;
                            this.initialTouchX = motionEvent.getRawX();
                            this.initialTouchY = motionEvent.getRawY();
                            break;
                        case MotionEvent.ACTION_MOVE:
                            MainUnlockerOverlayService.this.params.x = this.initialX + ((int) (motionEvent.getRawX() - this.initialTouchX));
                            MainUnlockerOverlayService.this.params.y = this.initialY + ((int) (motionEvent.getRawY() - this.initialTouchY));
                            if (MainUnlockerOverlayService.this.windowManager != null
                                    && MainUnlockerOverlayService.this.overlayView != null
                                    && MainUnlockerOverlayService.this.isViewAdded) {
                                try {
                                    MainUnlockerOverlayService.this.windowManager.updateViewLayout(
                                            MainUnlockerOverlayService.this.overlayView,
                                            MainUnlockerOverlayService.this.params);
                                } catch (Throwable ignored) {
                                }
                            }
                            break;
                        default:
                            break;
                    }
                    return true;
                }
            });
        } else {
            this.params.width = dp(24);
            this.params.height = dp(12);
            this.params.flags = 24;
            this.overlayView.setPadding(0, 0, 0, 0);
            this.overlayView.setBackgroundColor(0);
            this.overlayView.setText("");
            this.overlayView.setTextColor(0);
            this.overlayView.setAlpha(0.01f);
            this.overlayView.setOnTouchListener(null);
        }
        ensureAdded();
    }

    private void ensureAdded() {
        if (this.windowManager == null || this.overlayView == null || this.params == null) {
            return;
        }
        if (!this.isViewAdded) {
            try {
                this.windowManager.addView(this.overlayView, this.params);
                this.isViewAdded = true;
            } catch (Throwable ignored) {
            }
        } else {
            try {
                this.windowManager.updateViewLayout(this.overlayView, this.params);
            } catch (Throwable ignored) {
            }
        }
    }

    private int getLiveHz() {
        try {
            if (this.windowManager != null) {
                Display display = this.windowManager.getDefaultDisplay();
                if (display != null) {
                    float refreshRate = display.getRefreshRate();
                    if (refreshRate > 10.0f) {
                        return Math.round(refreshRate);
                    }
                }
            }
        } catch (Throwable ignored) {
        }
        return 120;
    }

    private int dp(int value) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, getResources().getDisplayMetrics());
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        RateLock.sOverlayServiceActive = false;
        RateLock.sOverlayVisibleMode = false;
        if (this.handler != null && this.runnable != null) {
            this.handler.removeCallbacks(this.runnable);
        }
        if (this.windowManager != null && this.overlayView != null && this.isViewAdded) {
            try {
                this.windowManager.removeView(this.overlayView);
            } catch (Throwable ignored) {
            }
            this.isViewAdded = false;
        }
    }
}
