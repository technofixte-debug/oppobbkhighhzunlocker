package com.pipidistrtop.hzunlocker;

import java.util.Collections;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/** Installed packages treated as games even without FLAG_IS_GAME. */
public final class KnownGames {
    private static final Set<String> NAMES;

    static {
        HashSet<String> set = new HashSet<String>();
        String[] names = new String[] {
            "com.axlebolt.standoff2",
            "com.supercell.brawlstars",
            "com.supercell.clashroyale",
            "com.supercell.clashofclans",
            "com.supercell.squad",
            "com.tencent.ig",
            "com.pubg.krmobile",
            "com.pubg.imobile",
            "com.vng.pubgmobile",
            "com.rekoo.pubgm",
            "com.activision.callofduty.shooter",
            "com.activision.callofduty.warzone",
            "com.garena.game.codm",
            "com.mihoyo.genshinimpact",
            "com.hoyoverse.hkrpgoversea",
            "com.hoyoverse.nap",
            "com.kurogame.wutheringwaves.global",
            "com.mobile.legends",
            "com.dts.freefireth",
            "com.dts.freefiremax",
            "com.mojang.minecraftpe",
            "com.roblox.client",
            "com.riotgames.league.wildrift",
            "com.levelinfinite.sgameglobal",
            "com.proximabeta.mf.uamo",
            "com.proxima.dfm",
            "com.gameloft.android.anmp.glofta9hm",
            "com.innersloth.spacemafia",
            "com.kiloo.subwaysurf",
            "jp.konami.pesam",
            "com.ea.gp.fifamobile",
            "com.criticalforceentertainment.criticalops",
            "com.kitkagames.fallbuddies",
            "com.pixonic.wwr",
            "net.wargaming.wot.blitz",
            "com.ea.games.r3_row"
        };
        for (int i = 0; i < names.length; i++) {
            set.add(names[i]);
        }
        NAMES = Collections.unmodifiableSet(set);
    }

    private KnownGames() {
    }

    public static boolean matches(String packageName) {
        if (packageName == null || packageName.length() == 0) {
            return false;
        }
        return NAMES.contains(packageName.toLowerCase(Locale.US));
    }
}
