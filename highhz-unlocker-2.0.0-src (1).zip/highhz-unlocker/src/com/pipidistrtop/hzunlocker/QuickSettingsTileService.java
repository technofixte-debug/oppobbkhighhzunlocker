package com.pipidistrtop.hzunlocker;

import android.annotation.TargetApi;
import android.content.SharedPreferences;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

@TargetApi(24)
public class QuickSettingsTileService extends TileService {
    @Override
    public void onStartListening() {
        super.onStartListening();
        updateTile();
    }

    @Override
    public void onClick() {
        super.onClick();
        SharedPreferences sharedPreferences = getSharedPreferences("FpsPrefs", 0);
        sharedPreferences.edit().putBoolean("fps_enabled", !sharedPreferences.getBoolean("fps_enabled", false)).apply();
        RateLock.applyState(this);
        updateTile();
    }

    private void updateTile() {
        try {
            Tile qsTile = getQsTile();
            if (qsTile != null) {
                SharedPreferences prefs = getSharedPreferences("FpsPrefs", 0);
                boolean enabled = prefs.getBoolean("fps_enabled", false);
                boolean watchdog = prefs.getBoolean("watchdog_mode", false);
                qsTile.setState(enabled ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE);
                String mode = getString(watchdog ? R.string.tile_mode_wd : R.string.tile_mode_cycle);
                qsTile.setLabel(getString(R.string.app_name));
                try {
                    Tile.class.getMethod("setSubtitle", CharSequence.class).invoke(qsTile, mode);
                } catch (Throwable ignored) {
                    qsTile.setLabel(getString(R.string.app_name) + " · " + mode);
                }
                qsTile.updateTile();
            }
        } catch (Exception ignored) {
        }
    }
}
