package com.pipidistrtop.hzunlocker;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    public static List<AppInfo> sAppsCache = null;
    public static HashMap<String, Drawable> sIcons = new HashMap<String, Drawable>();
    public static volatile boolean sLoading = false;
    private static int sLoadSeq = 0;

    private AmbientBackgroundView ambientBg;
    private NebulaOverlayView nebulaOverlay;
    private AppAdapter appAdapter;
    private ListView appListView;
    private LinearLayout autostartCard;
    private LinearLayout bottomNav;
    private View bottomNavBorder;
    private FrameLayout contentContainer;
    private TextView currentHzTextView;
    private Button filterOnlyEnabledBtn;
    private Runnable fpsUpdater;
    private TextView homeSubtitleView;
    private LinearLayout intervalCard;
    private TextView loadingIndicatorView;
    private TextView masterHintView;
    private CompoundButton.OnCheckedChangeListener masterListener;
    private TextView masterStatusView;
    private Switch masterSwitch;
    private Button themeButton;
    private Switch overlaySwitch;
    private CompoundButton.OnCheckedChangeListener overlayListener;
    private LinearLayout permReminderCard;
    private FrameLayout rootFrame;
    private EditText searchField;
    private SharedPreferences prefs;
    private TextView tabAboutBtn;
    private TextView tabHomeBtn;
    private TextView tabWatchdogBtn;
    private LinearLayout themePopupCard;
    private FrameLayout themePopupContainer;
    private TextView tileHintView;
    private LinearLayout uiContainer;
    private Handler uiHandler;
    private TextView wdSummaryStatusView;
    private Switch watchdogSwitch;
    private CompoundButton.OnCheckedChangeListener watchdogListener;
    private boolean isThemePopupOpen = false;
    private int currentTab = 0;
    private int currentTheme = 3;
    private final List<AppInfo> allApps = new ArrayList<AppInfo>();
    private final List<AppInfo> filteredApps = new ArrayList<AppInfo>();
    private boolean filterOnlyEnabled = false;
    private String searchQuery = "";
    private boolean showSystemApps = false;
    private List<Integer> supportedRates = new ArrayList<Integer>();

    private final SharedPreferences.OnSharedPreferenceChangeListener prefListener = new SharedPreferences.OnSharedPreferenceChangeListener() {
        @Override
        public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
            if ("fps_enabled".equals(key) || "watchdog_mode".equals(key)) {
                uiHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        syncTogglesFromPrefs();
                    }
                });
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN
                | WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        this.prefs = getSharedPreferences("FpsPrefs", 0);
        this.currentTheme = ThemeManager.getTheme(this);
        this.uiHandler = new Handler(Looper.getMainLooper());
        this.supportedRates = getSupportedRefreshRates();
        buildUI();
        applyTheme();
        RateLock.applyState(this);
        if (this.rootFrame != null) {
            this.rootFrame.requestFocus();
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        this.prefs.registerOnSharedPreferenceChangeListener(this.prefListener);
        syncTogglesFromPrefs();
    }

    @Override
    protected void onResume() {
        super.onResume();
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN
                | WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        startHzPeriodicUpdater();
        updateCurrentHzDisplay();
        syncTogglesFromPrefs();
        RateLock.applyState(this);
        hideKeyboard();
        if (this.searchField != null) {
            this.searchField.clearFocus();
        }
        if (this.rootFrame != null) {
            this.rootFrame.requestFocus();
        }
        if (sAppsCache != null && hasRealAppList(sAppsCache)) {
            if (this.allApps.isEmpty()) {
                publishApps(sAppsCache);
            } else {
                refreshListChrome();
            }
        } else {
            loadAppsData();
        }
    }

    @Override
    protected void onPause() {
        hideKeyboard();
        super.onPause();
        stopHzPeriodicUpdater();
        closeThemePopup();
    }

    @Override
    protected void onStop() {
        this.prefs.unregisterOnSharedPreferenceChangeListener(this.prefListener);
        super.onStop();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        layoutAmbient();
    }

    private void startHzPeriodicUpdater() {
        if (this.fpsUpdater == null) {
            this.fpsUpdater = new Runnable() {
                @Override
                public void run() {
                    MainActivity.this.updateCurrentHzDisplay();
                    MainActivity.this.updateWatchdogStatusLine();
                    MainActivity.this.uiHandler.postDelayed(this, 1000L);
                }
            };
        }
        this.uiHandler.post(this.fpsUpdater);
    }

    private void stopHzPeriodicUpdater() {
        if (this.fpsUpdater != null) {
            this.uiHandler.removeCallbacks(this.fpsUpdater);
        }
    }

    public List<Integer> getSupportedRefreshRates() {
        return RateLock.getSupportedRefreshRates(this);
    }

    private void loadAppsData() {
        if (sAppsCache != null && hasRealAppList(sAppsCache)) {
            if (this.allApps.isEmpty()) {
                publishApps(sAppsCache);
            } else {
                refreshListChrome();
            }
            return;
        }
        final int seq = ++sLoadSeq;
        sLoading = true;
        refreshListChrome();
        new Thread(new Runnable() {
            @Override
            public void run() {
                final ArrayList<AppInfo> loaded = queryInstalledApps();
                if (seq != sLoadSeq) {
                    return;
                }
                final boolean real = hasRealAppList(loaded);
                if (real && loaded.size() > 2) {
                    sAppsCache = loaded;
                } else {
                    sAppsCache = null;
                }
                sLoading = false;
                uiHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (seq != sLoadSeq) {
                            return;
                        }
                        if (real) {
                            publishApps(loaded);
                        } else {
                            publishApps(new ArrayList<AppInfo>());
                        }
                    }
                });
            }
        }).start();
    }

    private ArrayList<AppInfo> queryInstalledApps() {
        ArrayList<AppInfo> list = new ArrayList<AppInfo>();
        try {
            PackageManager packageManager = getPackageManager();
            List<ApplicationInfo> installed = packageManager.getInstalledApplications(PackageManager.GET_META_DATA);
            for (int i = 0; i < installed.size(); i++) {
                ApplicationInfo info = installed.get(i);
                String packageName = info.packageName;
                if ("android".equals(packageName)) {
                    continue;
                }
                boolean isGame = (info.flags & ApplicationInfo.FLAG_IS_GAME) != 0 || KnownGames.matches(packageName);
                boolean isSystem = (info.flags & ApplicationInfo.FLAG_SYSTEM) != 0
                        && (info.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0;
                list.add(new AppInfo(
                        packageManager.getApplicationLabel(info).toString(),
                        packageName,
                        isGame,
                        isSystem,
                        this.prefs.getBoolean("app_hz_" + packageName, false),
                        RateLock.getAppRate(this.prefs, this, packageName)));
                try {
                    if (!sIcons.containsKey(packageName)) {
                        sIcons.put(packageName, packageManager.getApplicationIcon(info));
                    }
                } catch (Throwable ignored) {
                }
            }
        } catch (Throwable ignored) {
        }
        Collections.sort(list, new Comparator<AppInfo>() {
            @Override
            public int compare(AppInfo left, AppInfo right) {
                if (left.isGame != right.isGame) {
                    return left.isGame ? -1 : 1;
                }
                return left.name.compareToIgnoreCase(right.name);
            }
        });
        for (int i = 0; i < list.size(); i++) {
            if (getPackageName().equals(list.get(i).packageName)) {
                list.add(0, list.remove(i));
                break;
            }
        }
        return list;
    }

    private boolean hasRealAppList(List<AppInfo> apps) {
        if (apps == null) {
            return false;
        }
        String self = getPackageName();
        for (int i = 0; i < apps.size(); i++) {
            AppInfo app = apps.get(i);
            if (app != null && app.packageName != null && !self.equals(app.packageName)) {
                return true;
            }
        }
        return false;
    }

    private void publishApps(List<AppInfo> apps) {
        this.allApps.clear();
        this.allApps.addAll(apps);
        filterApps();
        refreshListChrome();
    }

    private void filterApps() {
        this.filteredApps.clear();
        String query = this.searchQuery != null ? this.searchQuery.trim().toLowerCase() : "";
        AppInfo pinned = null;
        for (int i = 0; i < this.allApps.size(); i++) {
            AppInfo app = this.allApps.get(i);
            if (!this.showSystemApps && app.isSystem) {
                continue;
            }
            if (this.filterOnlyEnabled && !app.enabled) {
                continue;
            }
            if (query.length() > 0
                    && !app.name.toLowerCase().contains(query)
                    && !app.packageName.toLowerCase().contains(query)) {
                continue;
            }
            if (getPackageName().equals(app.packageName)) {
                pinned = app;
            } else {
                this.filteredApps.add(app);
            }
        }
        if (pinned != null) {
            this.filteredApps.add(0, pinned);
        }
        if (this.appAdapter != null) {
            this.appAdapter.notifyDataSetChanged();
        }
        updateOnlyEnabledButtonText();
        updatePermissionCardVisibility();
    }

    private void refreshListChrome() {
        if (this.loadingIndicatorView != null) {
            this.loadingIndicatorView.setVisibility(sLoading ? View.VISIBLE : View.GONE);
        }
        if (this.appListView != null) {
            this.appListView.setVisibility(!sLoading && hasRealAppList(this.allApps) ? View.VISIBLE : View.GONE);
        }
        updatePermissionCardVisibility();
    }

    private void updatePermissionCardVisibility() {
        if (this.permReminderCard != null) {
            this.permReminderCard.setVisibility(!sLoading && !hasRealAppList(this.allApps) ? View.VISIBLE : View.GONE);
        }
    }

    public static void setMaster(Context context, boolean enabled) {
        context.getSharedPreferences("FpsPrefs", 0).edit().putBoolean("fps_enabled", enabled).apply();
        RateLock.applyState(context);
    }

    private void syncTogglesFromPrefs() {
        boolean master = this.prefs.getBoolean("fps_enabled", false);
        boolean watchdog = this.prefs.getBoolean("watchdog_mode", false);
        boolean overlay = this.prefs.getBoolean("overlay_enabled", false);
        setSwitchChecked(this.masterSwitch, master, this.masterListener);
        setSwitchChecked(this.watchdogSwitch, watchdog, this.watchdogListener);
        setSwitchChecked(this.overlaySwitch, overlay, this.overlayListener);
        if (this.masterStatusView != null) {
            this.masterStatusView.setText(getString(master ? R.string.status_on : R.string.status_off));
            this.masterStatusView.setTextColor(master
                    ? ThemeManager.getAccentColor(this.currentTheme)
                    : ThemeManager.getSecondaryTextColor(this.currentTheme));
        }
        updateHeaderSubtitle();
        updateModeCopy();
        updateWatchdogStatusLine();
    }

    private void setSwitchChecked(Switch view, boolean checked, CompoundButton.OnCheckedChangeListener listener) {
        if (view == null) {
            return;
        }
        view.setOnCheckedChangeListener(null);
        view.setChecked(checked);
        view.jumpDrawablesToCurrentState();
        view.setOnCheckedChangeListener(listener);
    }

    private void updateModeCopy() {
        boolean watchdog = this.prefs.getBoolean("watchdog_mode", false);
        if (this.masterHintView != null) {
            this.masterHintView.setText(getString(watchdog ? R.string.desc_mode_wd : R.string.desc_mode_cycle));
        }
        if (this.intervalCard != null) {
            this.intervalCard.setVisibility(watchdog ? View.GONE : View.VISIBLE);
        }
        if (this.tileHintView != null) {
            this.tileHintView.setText(getString(watchdog ? R.string.tile_hint_wd : R.string.tile_hint_cycle));
        }
    }

    private void buildUI() {
        this.rootFrame = new FrameLayout(this);
        this.rootFrame.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
        this.rootFrame.setFocusable(true);
        this.rootFrame.setFocusableInTouchMode(true);
        this.rootFrame.setDescendantFocusability(ViewGroup.FOCUS_BEFORE_DESCENDANTS);
        this.ambientBg = new AmbientBackgroundView(this);
        this.rootFrame.addView(this.ambientBg);
        layoutAmbient();
        this.uiContainer = new LinearLayout(this);
        this.uiContainer.setOrientation(LinearLayout.VERTICAL);
        this.uiContainer.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setPadding(dp(16), dp(10), dp(16), dp(10));
        header.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.ic_launcher);
        LinearLayout.LayoutParams logoLp = new LinearLayout.LayoutParams(dp(32), dp(32));
        logoLp.setMargins(0, 0, dp(10), 0);
        logo.setLayoutParams(logoLp);
        header.addView(logo);
        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.setGravity(Gravity.CENTER_VERTICAL);
        titles.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));
        TextView title = new TextView(this);
        title.setText(getString(R.string.app_name));
        title.setTextSize(2, 16f);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(-1);
        titles.addView(title);
        this.homeSubtitleView = new TextView(this);
        this.homeSubtitleView.setTextSize(2, 10f);
        this.homeSubtitleView.setTextColor(ThemeManager.getSecondaryTextColor(this.currentTheme));
        this.homeSubtitleView.setPadding(0, dp(1), dp(6), 0);
        updateHeaderSubtitle();
        titles.addView(this.homeSubtitleView);
        header.addView(titles);
        Button themeButton = new Button(this);
        this.themeButton = themeButton;
        themeButton.setText(getString(R.string.theme));
        themeButton.setTextSize(2, 10.5f);
        themeButton.setTypeface(Typeface.DEFAULT_BOLD);
        themeButton.setTextColor(-1);
        themeButton.setPadding(dp(12), dp(4), dp(12), dp(4));
        themeButton.setLayoutParams(new LinearLayout.LayoutParams(-2, dp(32)));
        applyButtonPressFeedback(themeButton, 872415231, 1442840575, ThemeManager.getAccentColor(this.currentTheme), dp(10));
        themeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toggleThemePopup();
            }
        });
        header.addView(themeButton);
        this.uiContainer.addView(header);
        this.contentContainer = new FrameLayout(this);
        this.contentContainer.setLayoutParams(new LinearLayout.LayoutParams(-1, 0, 1f));
        this.uiContainer.addView(this.contentContainer);
        this.bottomNavBorder = new View(this);
        this.bottomNavBorder.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(1)));
        this.bottomNavBorder.setBackgroundColor(ThemeManager.getNavBorder(this.currentTheme));
        this.uiContainer.addView(this.bottomNavBorder);
        this.bottomNav = new LinearLayout(this);
        this.bottomNav.setOrientation(LinearLayout.HORIZONTAL);
        this.bottomNav.setPadding(dp(12), dp(6), dp(12), dp(10));
        this.bottomNav.setGravity(Gravity.CENTER);
        this.bottomNav.setBackgroundColor(ThemeManager.getNavColor(this.currentTheme));
        this.tabHomeBtn = createTabButton(getString(R.string.tab_home), 0);
        this.tabWatchdogBtn = createTabButton(getString(R.string.tab_watchdog), 1);
        this.tabAboutBtn = createTabButton(getString(R.string.tab_about), 2);
        this.bottomNav.addView(this.tabHomeBtn);
        this.bottomNav.addView(this.tabWatchdogBtn);
        this.bottomNav.addView(this.tabAboutBtn);
        this.uiContainer.addView(this.bottomNav);
        this.rootFrame.addView(this.uiContainer);
        this.nebulaOverlay = new NebulaOverlayView(this);
        this.nebulaOverlay.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        this.nebulaOverlay.setNebulaEnabled(this.prefs.getBoolean("nebula_enabled", false));
        this.nebulaOverlay.updateTheme(this.currentTheme);
        this.rootFrame.addView(this.nebulaOverlay);
        buildThemePopupView();
        setContentView(this.rootFrame);
        switchTab(0);
    }

    private void layoutAmbient() {
        if (this.ambientBg == null) {
            return;
        }
        DisplayMetrics metrics = new DisplayMetrics();
        try {
            getWindowManager().getDefaultDisplay().getRealMetrics(metrics);
        } catch (Throwable ignored) {
            getWindowManager().getDefaultDisplay().getMetrics(metrics);
        }
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(metrics.widthPixels, metrics.heightPixels);
        params.gravity = Gravity.TOP | Gravity.START;
        this.ambientBg.setLayoutParams(params);
        this.ambientBg.setScreenSize(metrics.widthPixels, metrics.heightPixels);
    }

    private void updateHeaderSubtitle() {
        if (this.homeSubtitleView != null) {
            boolean watchdog = this.prefs.getBoolean("watchdog_mode", false);
            this.homeSubtitleView.setText(getString(watchdog ? R.string.mode_short_wd : R.string.mode_short_cycle));
        }
    }

    private void buildThemePopupView() {
        this.themePopupContainer = new FrameLayout(this);
        this.themePopupContainer.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        this.themePopupContainer.setVisibility(View.GONE);
        this.themePopupContainer.setClickable(true);
        this.themePopupContainer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                closeThemePopup();
            }
        });
        this.themePopupCard = new LinearLayout(this);
        this.themePopupCard.setOrientation(LinearLayout.VERTICAL);
        this.themePopupCard.setPadding(dp(8), dp(8), dp(8), dp(8));
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(dp(200), -2);
        params.gravity = Gravity.TOP | Gravity.END;
        params.setMargins(0, dp(50), dp(16), 0);
        this.themePopupCard.setLayoutParams(params);
        renderThemePopupItems();
        this.themePopupContainer.addView(this.themePopupCard);
        this.rootFrame.addView(this.themePopupContainer);
    }

    private void renderThemePopupItems() {
        if (this.themePopupCard == null) {
            return;
        }
        this.themePopupCard.removeAllViews();
        GradientDrawable card = new GradientDrawable();
        card.setColor(-267774940);
        card.setCornerRadius(dp(16));
        card.setStroke(dp(1.5f), ThemeManager.getAccentColor(this.currentTheme));
        this.themePopupCard.setBackground(card);
        for (int i = 0; i < ThemeManager.THEME_NAMES.length; i++) {
            final int index = i;
            boolean selected = this.currentTheme == i;
            TextView item = new TextView(this);
            item.setText((selected ? "✓  " : "    ") + ThemeManager.THEME_NAMES[i]);
            item.setTextSize(2, 12f);
            item.setTypeface(Typeface.DEFAULT_BOLD);
            item.setPadding(dp(12), dp(10), dp(12), dp(10));
            item.setTextColor(selected ? ThemeManager.getAccentColor(this.currentTheme) : -1);
            GradientDrawable bg = new GradientDrawable();
            if (selected) {
                int accent = ThemeManager.getAccentColor(this.currentTheme);
                bg.setColor((accent & 0x00FFFFFF) | 0x33000000);
                bg.setCornerRadius(dp(10));
            } else {
                bg.setColor(0);
            }
            item.setBackground(bg);
            item.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    setThemeIndex(index);
                    renderThemePopupItems();
                    closeThemePopup();
                }
            });
            this.themePopupCard.addView(item);
        }
        View gap = new View(this);
        gap.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(6)));
        this.themePopupCard.addView(gap);
        final boolean nebulaOn = this.prefs.getBoolean("nebula_enabled", false);
        TextView nebula = new TextView(this);
        nebula.setText((nebulaOn ? "✓  " : "    ") + getString(R.string.nebula));
        nebula.setTextSize(2, 12f);
        nebula.setTypeface(Typeface.DEFAULT_BOLD);
        nebula.setPadding(dp(12), dp(10), dp(12), dp(10));
        nebula.setTextColor(nebulaOn ? -1 : ThemeManager.getSecondaryTextColor(this.currentTheme));
        GradientDrawable nebulaBg = new GradientDrawable();
        nebulaBg.setCornerRadius(dp(10));
        nebulaBg.setColor(nebulaOn ? 0x33FFFFFF : 0);
        nebula.setBackground(nebulaBg);
        nebula.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean next = !prefs.getBoolean("nebula_enabled", false);
                prefs.edit().putBoolean("nebula_enabled", next).apply();
                if (nebulaOverlay != null) {
                    nebulaOverlay.setNebulaEnabled(next);
                }
                renderThemePopupItems();
            }
        });
        this.themePopupCard.addView(nebula);
    }

    private void toggleThemePopup() {
        if (this.isThemePopupOpen) {
            closeThemePopup();
        } else {
            openThemePopup();
        }
    }

    private void openThemePopup() {
        if (this.themePopupContainer != null) {
            this.isThemePopupOpen = true;
            renderThemePopupItems();
            this.themePopupContainer.setVisibility(View.VISIBLE);
            this.themePopupContainer.setAlpha(0f);
            this.themePopupContainer.animate().alpha(1f).setDuration(180L).start();
        }
    }

    private void closeThemePopup() {
        if (this.themePopupContainer != null && this.isThemePopupOpen) {
            this.isThemePopupOpen = false;
            this.themePopupContainer.animate().alpha(0f).setDuration(150L).withEndAction(new Runnable() {
                @Override
                public void run() {
                    if (themePopupContainer != null) {
                        themePopupContainer.setVisibility(View.GONE);
                    }
                }
            }).start();
        }
    }

    private TextView createTabButton(String label, final int index) {
        TextView button = new TextView(this);
        button.setText(label);
        button.setTextSize(2, 12f);
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setGravity(Gravity.CENTER);
        button.setPadding(dp(10), dp(6), dp(10), dp(6));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, -2, 1f);
        params.setMargins(dp(2), 0, dp(2), 0);
        button.setLayoutParams(params);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switchTab(index);
            }
        });
        return button;
    }

    private void switchTab(int index) {
        if (this.currentTab == index && this.contentContainer.getChildCount() > 0) {
            return;
        }
        this.currentTab = index;
        updateTabStyles();
        this.contentContainer.removeAllViews();
        View page;
        if (index == 0) {
            page = createHomeView();
        } else if (index == 1) {
            page = createWatchdogView();
        } else {
            page = createAboutView();
        }
        page.setAlpha(0f);
        this.contentContainer.addView(page);
        page.animate().alpha(1f).setDuration(200L).start();
    }

    private void updateTabStyles() {
        int accent = ThemeManager.getAccentColor(this.currentTheme);
        int secondary = ThemeManager.getSecondaryTextColor(this.currentTheme);
        setTabBtnStyle(this.tabHomeBtn, this.currentTab == 0, accent, secondary);
        setTabBtnStyle(this.tabWatchdogBtn, this.currentTab == 1, accent, secondary);
        setTabBtnStyle(this.tabAboutBtn, this.currentTab == 2, accent, secondary);
    }

    private void setTabBtnStyle(TextView button, boolean selected, int accent, int secondary) {
        if (button == null) {
            return;
        }
        GradientDrawable bg = new GradientDrawable();
        if (selected) {
            bg.setColor((16777215 & accent) | 855638016);
            bg.setCornerRadius(dp(16));
            bg.setStroke(dp(1.2f), accent);
            button.setTextColor(accent);
        } else {
            bg.setColor(0);
            button.setTextColor(secondary);
        }
        button.setBackground(bg);
    }

    private View createHomeView() {
        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
        LinearLayout column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        column.setPadding(dp(16), dp(10), dp(16), dp(20));

        LinearLayout rateCard = createCard();
        rateCard.setGravity(Gravity.CENTER);
        rateCard.setPadding(dp(16), dp(20), dp(16), dp(20));
        this.currentHzTextView = new TextView(this);
        this.currentHzTextView.setText(getString(R.string.fmt_hz, Integer.valueOf(getDisplayRefreshRate())));
        this.currentHzTextView.setTextSize(2, 44f);
        this.currentHzTextView.setTypeface(Typeface.DEFAULT_BOLD);
        this.currentHzTextView.setTextColor(ThemeManager.getAccentColor(this.currentTheme));
        rateCard.addView(this.currentHzTextView);
        TextView rateCaption = new TextView(this);
        rateCaption.setText(getString(R.string.screen_rate_caption));
        rateCaption.setTextSize(2, 11.5f);
        rateCaption.setTextColor(ThemeManager.getSecondaryTextColor(this.currentTheme));
        rateCard.addView(rateCaption);
        column.addView(rateCard);
        addVerticalSpace(column, 12);

        LinearLayout toggleCard = createCard();
        boolean master = this.prefs.getBoolean("fps_enabled", false);
        this.masterListener = new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton button, boolean checked) {
                setMaster(MainActivity.this, checked);
                if (masterStatusView != null) {
                    masterStatusView.setText(getString(checked ? R.string.status_on : R.string.status_off));
                    masterStatusView.setTextColor(checked
                            ? ThemeManager.getAccentColor(currentTheme)
                            : ThemeManager.getSecondaryTextColor(currentTheme));
                }
                updateHeaderSubtitle();
                updateModeCopy();
                updateWatchdogStatusLine();
            }
        };
        Switch[] masterSlot = new Switch[1];
        TextView[] hintSlot = new TextView[1];
        toggleCard.addView(createToggleRow(
                getString(R.string.master_title),
                getString(this.prefs.getBoolean("watchdog_mode", false) ? R.string.desc_mode_wd : R.string.desc_mode_cycle),
                master,
                this.masterListener,
                masterSlot,
                hintSlot));
        this.masterSwitch = masterSlot[0];
        this.masterHintView = hintSlot[0];
        this.masterStatusView = new TextView(this);
        this.masterStatusView.setText(getString(master ? R.string.status_on : R.string.status_off));
        this.masterStatusView.setTextSize(2, 11f);
        this.masterStatusView.setTextColor(master
                ? ThemeManager.getAccentColor(this.currentTheme)
                : ThemeManager.getSecondaryTextColor(this.currentTheme));
        toggleCard.addView(this.masterStatusView);
        addDivider(toggleCard);
        this.overlayListener = new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton button, boolean checked) {
                toggleOverlay(checked);
            }
        };
        Switch[] overlaySlot = new Switch[1];
        toggleCard.addView(createToggleRow(
                getString(R.string.overlay_title),
                getString(R.string.overlay_desc),
                this.prefs.getBoolean("overlay_enabled", false),
                this.overlayListener,
                overlaySlot,
                null));
        this.overlaySwitch = overlaySlot[0];
        column.addView(toggleCard);
        addVerticalSpace(column, 12);

        this.intervalCard = createCard();
        TextView intervalTitle = new TextView(this);
        intervalTitle.setText(getString(R.string.interval_title));
        intervalTitle.setTextSize(2, 12f);
        intervalTitle.setTypeface(Typeface.DEFAULT_BOLD);
        intervalTitle.setTextColor(-1);
        this.intervalCard.addView(intervalTitle);
        final LinearLayout intervalRow = new LinearLayout(this);
        intervalRow.setOrientation(LinearLayout.HORIZONTAL);
        intervalRow.setPadding(0, dp(8), 0, 0);
        final int[] values = new int[] {250, 500, 1000, 2000};
        final int[] labels = new int[] {
            R.string.interval_250, R.string.interval_500, R.string.interval_1000, R.string.interval_2000
        };
        int selected = this.prefs.getInt("watchdog_interval", 1000);
        if (selected == 350) {
            selected = 250;
            this.prefs.edit().putInt("watchdog_interval", 250).apply();
        }
        for (int i = 0; i < values.length; i++) {
            final int value = values[i];
            Button button = new Button(this);
            button.setText(getString(labels[i]));
            button.setTextSize(2, 11f);
            button.setTypeface(Typeface.DEFAULT_BOLD);
            button.setPadding(dp(4), dp(6), dp(4), dp(6));
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, dp(36), 1f);
            params.setMargins(dp(2), 0, dp(2), 0);
            button.setLayoutParams(params);
            updateDelayButtonStyle(button, selected == value);
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    prefs.edit().putInt("watchdog_interval", value).apply();
                    for (int child = 0; child < intervalRow.getChildCount(); child++) {
                        View item = intervalRow.getChildAt(child);
                        if (item instanceof Button) {
                            updateDelayButtonStyle((Button) item, values[child] == value);
                        }
                    }
                }
            });
            intervalRow.addView(button);
        }
        this.intervalCard.addView(intervalRow);
        this.intervalCard.setVisibility(this.prefs.getBoolean("watchdog_mode", false) ? View.GONE : View.VISIBLE);
        column.addView(this.intervalCard);
        addVerticalSpace(column, 12);

        LinearLayout tileCard = createCard();
        TextView tileTitle = new TextView(this);
        tileTitle.setText(getString(R.string.tile_card_title));
        tileTitle.setTextSize(2, 12f);
        tileTitle.setTypeface(Typeface.DEFAULT_BOLD);
        tileTitle.setTextColor(-1);
        tileCard.addView(tileTitle);
        this.tileHintView = new TextView(this);
        this.tileHintView.setTextSize(2, 10.5f);
        this.tileHintView.setTextColor(ThemeManager.getSecondaryTextColor(this.currentTheme));
        this.tileHintView.setPadding(0, dp(4), 0, 0);
        this.tileHintView.setText(getString(this.prefs.getBoolean("watchdog_mode", false)
                ? R.string.tile_hint_wd : R.string.tile_hint_cycle));
        tileCard.addView(this.tileHintView);
        column.addView(tileCard);
        scroll.addView(column);
        return scroll;
    }

    private void updateDelayButtonStyle(Button button, boolean selected) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(selected ? ThemeManager.getAccentColor(this.currentTheme) : 587202559);
        bg.setCornerRadius(dp(8));
        button.setTextColor(selected ? -16249576 : -1);
        button.setBackground(bg);
    }

    private View createWatchdogView() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(14), dp(4), dp(14), dp(4));
        header.setLayoutParams(new ScrollView.LayoutParams(-1, -2));

        LinearLayout modeCard = createCard();
        modeCard.setPadding(dp(12), dp(10), dp(12), dp(10));
        boolean watchdog = this.prefs.getBoolean("watchdog_mode", false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));
        TextView title = new TextView(this);
        title.setText(getString(R.string.wd_title));
        title.setTextSize(2, 12.5f);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(-1);
        texts.addView(title);
        this.wdSummaryStatusView = new TextView(this);
        this.wdSummaryStatusView.setTextSize(2, 10.5f);
        this.wdSummaryStatusView.setTextColor(ThemeManager.getSecondaryTextColor(this.currentTheme));
        texts.addView(this.wdSummaryStatusView);
        row.addView(texts);
        this.watchdogListener = new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton button, boolean checked) {
                prefs.edit().putBoolean("watchdog_mode", checked).apply();
                RateLock.applyState(MainActivity.this);
                updateWatchdogStatusLine();
                updateHeaderSubtitle();
                updateModeCopy();
            }
        };
        this.watchdogSwitch = new Switch(this);
        this.watchdogSwitch.setChecked(watchdog);
        this.watchdogSwitch.jumpDrawablesToCurrentState();
        this.watchdogSwitch.setOnCheckedChangeListener(this.watchdogListener);
        row.addView(this.watchdogSwitch);
        modeCard.addView(row);
        Button clearVotes = new Button(this);
        clearVotes.setText(getString(R.string.clear_votes));
        clearVotes.setTextSize(2, 10f);
        clearVotes.setTypeface(Typeface.DEFAULT_BOLD);
        clearVotes.setTextColor(-1);
        LinearLayout.LayoutParams clearLp = new LinearLayout.LayoutParams(-2, dp(30));
        clearLp.setMargins(0, dp(6), 0, 0);
        clearVotes.setLayoutParams(clearLp);
        clearVotes.setPadding(dp(10), 0, dp(10), 0);
        applyButtonPressFeedback(clearVotes, 687817796, 1442792516, -43691, dp(8));
        clearVotes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RateLock.sExecutor.execute(new Runnable() {
                    @Override
                    public void run() {
                        RateLock.releaseAll(MainActivity.this);
                        SharedPreferences.Editor editor = prefs.edit();
                        java.util.Map<String, ?> all = prefs.getAll();
                        for (java.util.Map.Entry<String, ?> entry : all.entrySet()) {
                            String key = entry.getKey();
                            if (key != null && key.startsWith("app_hz_")) {
                                editor.remove(key);
                            }
                        }
                        editor.commit();
                        uiHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                for (int i = 0; i < allApps.size(); i++) {
                                    allApps.get(i).enabled = false;
                                }
                                if (appAdapter != null) {
                                    appAdapter.notifyDataSetChanged();
                                }
                                updateWatchdogStatusLine();
                                updateOnlyEnabledButtonText();
                            }
                        });
                    }
                });
            }
        });
        modeCard.addView(clearVotes);
        header.addView(modeCard);
        addVerticalSpace(header, 6);

        this.autostartCard = createCard();
        this.autostartCard.setPadding(dp(14), dp(12), dp(14), dp(12));
        int autostartRed = 0xFFFF3B30;
        GradientDrawable autostartBg = new GradientDrawable();
        autostartBg.setColor(0xFF3A1214);
        autostartBg.setCornerRadius(dp(14));
        autostartBg.setStroke(dp(2), autostartRed);
        this.autostartCard.setBackground(autostartBg);
        TextView autostartTitle = new TextView(this);
        autostartTitle.setText(getString(R.string.autostart_title));
        autostartTitle.setTextSize(2, 15f);
        autostartTitle.setTypeface(Typeface.DEFAULT_BOLD);
        autostartTitle.setTextColor(autostartRed);
        this.autostartCard.addView(autostartTitle);
        TextView autostartText = new TextView(this);
        autostartText.setText(getString(R.string.autostart_body));
        autostartText.setTextSize(2, 13f);
        autostartText.setTextColor(-1);
        autostartText.setPadding(0, dp(6), 0, dp(2));
        this.autostartCard.addView(autostartText);
        Button dismiss = new Button(this);
        dismiss.setText(getString(R.string.autostart_dismiss));
        dismiss.setTextSize(2, 12f);
        dismiss.setAllCaps(false);
        dismiss.setGravity(Gravity.CENTER);
        dismiss.setTextColor(-1);
        dismiss.setSingleLine(true);
        dismiss.setMinHeight(0);
        dismiss.setMinimumHeight(0);
        dismiss.setPadding(dp(8), dp(8), dp(8), dp(8));
        LinearLayout.LayoutParams dismissLp = new LinearLayout.LayoutParams(-1, dp(40));
        dismissLp.setMargins(0, dp(10), 0, dp(2));
        dismiss.setLayoutParams(dismissLp);
        applyButtonPressFeedback(dismiss, 0xFFD32F2F, 0xFFFF8A80, 0xFFFF3B30, dp(8));
        dismiss.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                prefs.edit().putBoolean("hint_autostart_dismissed", true).apply();
                if (autostartCard != null) {
                    autostartCard.setVisibility(View.GONE);
                }
            }
        });
        this.autostartCard.addView(dismiss);
        this.autostartCard.setVisibility(this.prefs.getBoolean("hint_autostart_dismissed", false) ? View.GONE : View.VISIBLE);
        header.addView(this.autostartCard);
        addVerticalSpace(header, 6);

        this.permReminderCard = createCard();
        this.permReminderCard.setPadding(dp(12), dp(8), dp(12), dp(8));
        TextView permTitle = new TextView(this);
        permTitle.setText(getString(R.string.perm_title));
        permTitle.setTextSize(2, 11.5f);
        permTitle.setTypeface(Typeface.DEFAULT_BOLD);
        permTitle.setTextColor(-1);
        this.permReminderCard.addView(permTitle);
        TextView permBody = new TextView(this);
        permBody.setText(getString(R.string.perm_body));
        permBody.setTextSize(2, 10.5f);
        permBody.setTextColor(ThemeManager.getSecondaryTextColor(this.currentTheme));
        permBody.setPadding(0, dp(2), 0, dp(4));
        this.permReminderCard.addView(permBody);
        Button permButton = new Button(this);
        permButton.setText(getString(R.string.perm_button));
        permButton.setTextSize(2, 10f);
        permButton.setTypeface(Typeface.DEFAULT_BOLD);
        permButton.setTextColor(ThemeManager.getAccentColor(this.currentTheme));
        applyButtonPressFeedback(permButton, 579387600, 1149812944, ThemeManager.getAccentColor(this.currentTheme), dp(8));
        permButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    openPermissionSettings();
                } catch (Throwable ignored) {
                }
            }
        });
        this.permReminderCard.addView(permButton);
        this.permReminderCard.setVisibility(!sLoading && !hasRealAppList(this.allApps) ? View.VISIBLE : View.GONE);
        header.addView(this.permReminderCard);

        this.searchField = new EditText(this);
        this.searchField.setHint(getString(R.string.search_hint));
        this.searchField.setHintTextColor(ThemeManager.getSecondaryTextColor(this.currentTheme));
        this.searchField.setTextColor(-1);
        this.searchField.setTextSize(2, 11.5f);
        this.searchField.setSingleLine(true);
        this.searchField.setPadding(dp(10), dp(6), dp(10), dp(6));
        LinearLayout.LayoutParams searchLp = new LinearLayout.LayoutParams(-1, dp(36));
        searchLp.setMargins(0, dp(2), 0, dp(4));
        this.searchField.setLayoutParams(searchLp);
        GradientDrawable searchBg = new GradientDrawable();
        searchBg.setColor(ThemeManager.getCardColor(this.currentTheme));
        searchBg.setCornerRadius(dp(8));
        searchBg.setStroke(dp(1), ThemeManager.getCardStroke(this.currentTheme));
        this.searchField.setBackground(searchBg);
        if (this.searchQuery != null && this.searchQuery.length() > 0) {
            this.searchField.setText(this.searchQuery);
            this.searchField.setSelection(this.searchQuery.length());
        }
        this.searchField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                searchQuery = editable != null ? editable.toString() : "";
                filterApps();
            }
        });
        this.searchField.clearFocus();
        header.addView(this.searchField);

        HorizontalScrollView filters = new HorizontalScrollView(this);
        filters.setHorizontalScrollBarEnabled(false);
        LinearLayout filterRow = new LinearLayout(this);
        filterRow.setOrientation(LinearLayout.HORIZONTAL);
        filterRow.setGravity(Gravity.CENTER_VERTICAL);
        filterRow.setPadding(0, dp(2), 0, dp(4));
        TextView systemLabel = new TextView(this);
        systemLabel.setText(getString(R.string.system_apps));
        systemLabel.setTextSize(2, 10.5f);
        systemLabel.setTextColor(ThemeManager.getSecondaryTextColor(this.currentTheme));
        systemLabel.setPadding(0, 0, dp(4), 0);
        filterRow.addView(systemLabel);
        Switch systemSwitch = new Switch(this);
        systemSwitch.setChecked(this.showSystemApps);
        systemSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton button, boolean checked) {
                showSystemApps = checked;
                filterApps();
            }
        });
        filterRow.addView(systemSwitch);
        this.filterOnlyEnabledBtn = new Button(this);
        this.filterOnlyEnabledBtn.setTextSize(2, 10f);
        this.filterOnlyEnabledBtn.setTypeface(Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams filterLp = new LinearLayout.LayoutParams(-2, dp(30));
        filterLp.setMargins(dp(6), 0, dp(4), 0);
        this.filterOnlyEnabledBtn.setLayoutParams(filterLp);
        this.filterOnlyEnabledBtn.setPadding(dp(8), 0, dp(8), 0);
        updateOnlyEnabledButtonStyle();
        this.filterOnlyEnabledBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                filterOnlyEnabled = !filterOnlyEnabled;
                updateOnlyEnabledButtonStyle();
                filterApps();
            }
        });
        filterRow.addView(this.filterOnlyEnabledBtn);
        Button selectAll = createCompactBatchBtn(getString(R.string.select_all));
        selectAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setFilteredAppsSelected(true);
            }
        });
        filterRow.addView(selectAll);
        Button clearAll = createCompactBatchBtn(getString(R.string.clear_all));
        clearAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setFilteredAppsSelected(false);
            }
        });
        filterRow.addView(clearAll);
        Button games = createCompactBatchBtn(getString(R.string.games_only));
        games.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setFilteredGamesOnly();
            }
        });
        filterRow.addView(games);
        filters.addView(filterRow);
        header.addView(filters);
        final int maxHeader = Math.max(dp(280), (int) (getResources().getDisplayMetrics().heightPixels * 0.62f));
        ScrollView headerScroll = new ScrollView(this) {
            @Override
            protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
                super.onMeasure(widthMeasureSpec, heightMeasureSpec);
                if (getMeasuredHeight() > maxHeader) {
                    setMeasuredDimension(getMeasuredWidth(), maxHeader);
                }
            }
        };
        headerScroll.setFillViewport(false);
        headerScroll.setVerticalScrollBarEnabled(false);
        headerScroll.addView(header);
        page.addView(headerScroll);

        this.loadingIndicatorView = new TextView(this);
        this.loadingIndicatorView.setText(getString(R.string.loading_apps));
        this.loadingIndicatorView.setTextSize(2, 12f);
        this.loadingIndicatorView.setTextColor(ThemeManager.getSecondaryTextColor(this.currentTheme));
        this.loadingIndicatorView.setGravity(Gravity.CENTER);
        this.loadingIndicatorView.setPadding(dp(20), dp(30), dp(20), dp(30));
        page.addView(this.loadingIndicatorView);

        this.appListView = new ListView(this);
        this.appListView.setLayoutParams(new LinearLayout.LayoutParams(-1, 0, 1f));
        this.appListView.setDivider(new ColorDrawable(ThemeManager.getCardStroke(this.currentTheme)));
        this.appListView.setDividerHeight(dp(1));
        this.appListView.setFastScrollEnabled(false);
        this.appListView.setClipToPadding(false);
        this.appListView.setPadding(0, 0, 0, dp(12));
        this.appAdapter = new AppAdapter();
        this.appListView.setAdapter(this.appAdapter);
        page.addView(this.appListView);
        refreshListChrome();
        updateWatchdogStatusLine();
        if (this.rootFrame != null) {
            this.rootFrame.requestFocus();
        }
        this.uiHandler.post(new Runnable() {
            @Override
            public void run() {
                if (searchField != null) {
                    searchField.clearFocus();
                }
                if (rootFrame != null) {
                    rootFrame.requestFocus();
                }
                hideKeyboard();
            }
        });
        return page;
    }

    private void openAutostartSettings() {
        String[] actions = new String[] {
            "com.oplus.battery.permission.startup.StartupAppListActivity",
            "com.coloros.safecenter.startupapp.permission.STARTUP_APP_LIST",
            "com.oppo.safe.permission.startup.STARTUP_APP_LIST",
            "oplus.intent.action.STARTUP_APP_LIST"
        };
        String[] actionPackages = new String[] {
            "com.oplus.battery",
            "com.coloros.safecenter",
            "com.oppo.safe",
            "com.oplus.battery"
        };
        for (int i = 0; i < actions.length; i++) {
            Intent intent = new Intent(actions[i]);
            intent.setPackage(actionPackages[i]);
            intent.addCategory(Intent.CATEGORY_DEFAULT);
            if (startIntent(intent)) {
                return;
            }
        }
        if (startExportedStartupActivity()) {
            return;
        }
        if (startComponent("com.oplus.battery", "com.oplus.startupapp.view.StartupAppListActivity")) {
            return;
        }
        String[][] pages = new String[][] {
            {"com.oplus.safecenter", "com.oplus.safecenter.startupapp.StartupAppListActivity"},
            {"com.oplus.safecenter", "com.oplus.safecenter.startupapp.view.StartupAppListActivity"},
            {"com.coloros.safecenter", "com.coloros.safecenter.startupapp.StartupAppListActivity"},
            {"com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"},
            {"com.coloros.safecenter", "com.coloros.safecenter.permission.startupapp.StartupAppListActivity"},
            {"com.oppo.safe", "com.oppo.safe.permission.startup.StartupAppListActivity"}
        };
        for (int i = 0; i < pages.length; i++) {
            if (startComponent(pages[i][0], pages[i][1])) {
                return;
            }
        }
        try {
            Intent apps = new Intent("android.settings.APPLICATION_SETTINGS");
            apps.addCategory(Intent.CATEGORY_DEFAULT);
            apps.setPackage("com.android.settings");
            startActivity(apps);
        } catch (Throwable ignored) {
            try {
                startActivity(new Intent("android.settings.APPLICATION_SETTINGS"));
            } catch (Throwable ignored2) {
            }
        }
    }

    private boolean startExportedStartupActivity() {
        String[] packages = new String[] {
            "com.oplus.battery",
            "com.oplus.safecenter",
            "com.coloros.safecenter",
            "com.oppo.safe"
        };
        PackageManager packageManager = getPackageManager();
        for (int i = 0; i < packages.length; i++) {
            try {
                PackageInfo info = packageManager.getPackageInfo(packages[i], PackageManager.GET_ACTIVITIES);
                if (info == null || info.activities == null) {
                    continue;
                }
                for (int a = 0; a < info.activities.length; a++) {
                    ActivityInfo activity = info.activities[a];
                    if (activity == null || activity.name == null || !activity.exported) {
                        continue;
                    }
                    if (activity.permission != null && activity.permission.length() > 0) {
                        continue;
                    }
                    String name = activity.name.toLowerCase(Locale.US);
                    if (name.contains("startup") && startComponent(packages[i], activity.name)) {
                        return true;
                    }
                }
            } catch (Throwable ignored) {
            }
        }
        return false;
    }

    private boolean startIntent(Intent intent) {
        try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            return true;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private void openPermissionSettings() {
        try {
            Intent intent = new Intent();
            intent.setComponent(new ComponentName(
                    "com.oplus.securitypermission",
                    "com.oplusos.securitypermission.permission.PermissionGroupsActivity"));
            intent.putExtra("packageName", getPackageName());
            intent.putExtra("PackageName", getPackageName());
            intent.putExtra("packageLabel", getString(R.string.app_name));
            intent.putExtra(Intent.EXTRA_PACKAGE_NAME, getPackageName());
            intent.setData(Uri.parse("package:" + getPackageName()));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            return;
        } catch (Throwable ignored) {
        }
        try {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            intent.setData(Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } catch (Throwable ignored2) {
        }
    }

    private boolean startComponent(String packageName, String className) {
        Intent intent = new Intent();
        intent.setComponent(new ComponentName(packageName, className));
        return startIntent(intent);
    }

    private void updateOnlyEnabledButtonText() {
        if (this.filterOnlyEnabledBtn == null) {
            return;
        }
        int enabled = 0;
        for (int i = 0; i < this.allApps.size(); i++) {
            if (this.allApps.get(i).enabled) {
                enabled++;
            }
        }
        this.filterOnlyEnabledBtn.setText(getString(this.filterOnlyEnabled ? R.string.filter_on_active : R.string.filter_on, Integer.valueOf(enabled)));
    }

    private void updateOnlyEnabledButtonStyle() {
        if (this.filterOnlyEnabledBtn == null) {
            return;
        }
        updateOnlyEnabledButtonText();
        GradientDrawable bg = new GradientDrawable();
        int accent = ThemeManager.getAccentColor(this.currentTheme);
        if (this.filterOnlyEnabled) {
            bg.setColor((16777215 & accent) | 1291845632);
            bg.setStroke(dp(1.2f), accent);
            this.filterOnlyEnabledBtn.setTextColor(accent);
        } else {
            bg.setColor(587202559);
            bg.setStroke(dp(1), 872415231);
            this.filterOnlyEnabledBtn.setTextColor(-1);
        }
        bg.setCornerRadius(dp(8));
        this.filterOnlyEnabledBtn.setBackground(bg);
    }

    private Button createCompactBatchBtn(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextSize(2, 10f);
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setTextColor(-1);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-2, dp(30));
        params.setMargins(dp(2), 0, dp(2), 0);
        button.setLayoutParams(params);
        button.setPadding(dp(8), 0, dp(8), 0);
        applyButtonPressFeedback(button, 587202559, 1157627903, ThemeManager.getAccentColor(this.currentTheme), dp(8));
        return button;
    }

    private void updateWatchdogStatusLine() {
        if (this.wdSummaryStatusView == null) {
            return;
        }
        if (!this.prefs.getBoolean("fps_enabled", false)) {
            this.wdSummaryStatusView.setText(getString(R.string.wd_status_master_off));
        } else if (!this.prefs.getBoolean("watchdog_mode", false)) {
            this.wdSummaryStatusView.setText(getString(R.string.wd_status_cycle));
        } else {
            this.wdSummaryStatusView.setText(getString(R.string.wd_status_votes));
        }
    }

    private void setFilteredAppsSelected(final boolean selected) {
        RateLock.sExecutor.execute(new Runnable() {
            @Override
            public void run() {
                SharedPreferences.Editor editor = prefs.edit();
                boolean master = prefs.getBoolean("fps_enabled", false);
                boolean watchdog = prefs.getBoolean("watchdog_mode", false);
                for (int i = 0; i < filteredApps.size(); i++) {
                    AppInfo app = filteredApps.get(i);
                    app.enabled = selected;
                    editor.putBoolean("app_hz_" + app.packageName, selected);
                    if (master && watchdog) {
                        if (selected) {
                            int rate = RateLock.getAppRate(prefs, MainActivity.this, app.packageName);
                            app.targetHz = rate;
                            RateLock.recordPackageDiag(app.packageName, RateLock.hzToRateId(rate),
                                    RateLock.arm(MainActivity.this, app.packageName, RateLock.hzToRateId(rate)) ? 1 : 0,
                                    Oiface.registerGame(app.packageName));
                        } else {
                            RateLock.release(MainActivity.this, app.packageName);
                            Oiface.unregisterGame(app.packageName);
                            RateLock.removePackageDiag(app.packageName);
                        }
                    }
                }
                editor.apply();
                RateLock.applyState(MainActivity.this);
                uiHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (appAdapter != null) {
                            appAdapter.notifyDataSetChanged();
                        }
                        updateWatchdogStatusLine();
                        updateOnlyEnabledButtonText();
                    }
                });
            }
        });
    }

    private void setFilteredGamesOnly() {
        RateLock.sExecutor.execute(new Runnable() {
            @Override
            public void run() {
                SharedPreferences.Editor editor = prefs.edit();
                boolean master = prefs.getBoolean("fps_enabled", false);
                boolean watchdog = prefs.getBoolean("watchdog_mode", false);
                for (int i = 0; i < filteredApps.size(); i++) {
                    AppInfo app = filteredApps.get(i);
                    app.enabled = app.isGame;
                    editor.putBoolean("app_hz_" + app.packageName, app.isGame);
                    if (master && watchdog) {
                        if (app.isGame) {
                            int rate = RateLock.getAppRate(prefs, MainActivity.this, app.packageName);
                            app.targetHz = rate;
                            RateLock.recordPackageDiag(app.packageName, RateLock.hzToRateId(rate),
                                    RateLock.arm(MainActivity.this, app.packageName, RateLock.hzToRateId(rate)) ? 1 : 0,
                                    Oiface.registerGame(app.packageName));
                        } else {
                            RateLock.release(MainActivity.this, app.packageName);
                            Oiface.unregisterGame(app.packageName);
                            RateLock.removePackageDiag(app.packageName);
                        }
                    }
                }
                editor.apply();
                RateLock.applyState(MainActivity.this);
                uiHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (appAdapter != null) {
                            appAdapter.notifyDataSetChanged();
                        }
                        updateWatchdogStatusLine();
                        updateOnlyEnabledButtonText();
                    }
                });
            }
        });
    }

    private class AppAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return filteredApps.size();
        }

        @Override
        public AppInfo getItem(int position) {
            return filteredApps.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ViewHolder holder;
            if (convertView == null) {
                convertView = buildAppRow();
                holder = (ViewHolder) convertView.getTag();
            } else {
                holder = (ViewHolder) convertView.getTag();
            }
            final AppInfo item = getItem(position);
            holder.title.setText(item.name);
            holder.pkg.setText(item.packageName);
            if (getPackageName().equals(item.packageName)) {
                holder.gameBadge.setText("★");
                holder.gameBadge.setVisibility(View.VISIBLE);
            } else if (item.isGame) {
                holder.gameBadge.setText(getString(R.string.badge_game));
                holder.gameBadge.setVisibility(View.VISIBLE);
            } else {
                holder.gameBadge.setVisibility(View.GONE);
            }
            Drawable icon = sIcons.get(item.packageName);
            if (icon != null) {
                holder.icon.setImageDrawable(icon);
            } else {
                holder.icon.setImageResource(R.drawable.ic_launcher);
            }
            item.targetHz = RateLock.getAppRate(prefs, MainActivity.this, item.packageName);
            holder.rateBtn.setText(getString(R.string.fmt_hz, Integer.valueOf(item.targetHz)));
            holder.rateBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    showRatePicker(view, item);
                }
            });
            holder.toggle.setOnCheckedChangeListener(null);
            holder.toggle.setChecked(item.enabled);
            holder.toggle.jumpDrawablesToCurrentState();
            holder.toggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton button, final boolean checked) {
                    item.enabled = checked;
                    prefs.edit().putBoolean("app_hz_" + item.packageName, checked).apply();
                    RateLock.sExecutor.execute(new Runnable() {
                        @Override
                        public void run() {
                            boolean master = prefs.getBoolean("fps_enabled", false);
                            boolean watchdog = prefs.getBoolean("watchdog_mode", false);
                            if (master && watchdog) {
                                if (checked) {
                                    int rate = RateLock.getAppRate(prefs, MainActivity.this, item.packageName);
                                    item.targetHz = rate;
                                    RateLock.recordPackageDiag(item.packageName, RateLock.hzToRateId(rate),
                                            RateLock.arm(MainActivity.this, item.packageName, RateLock.hzToRateId(rate)) ? 1 : 0,
                                            Oiface.registerGame(item.packageName));
                                } else {
                                    RateLock.release(MainActivity.this, item.packageName);
                                    Oiface.unregisterGame(item.packageName);
                                    RateLock.removePackageDiag(item.packageName);
                                }
                            }
                            uiHandler.post(new Runnable() {
                                @Override
                                public void run() {
                                    updateWatchdogStatusLine();
                                    updateOnlyEnabledButtonText();
                                }
                            });
                        }
                    });
                }
            });
            return convertView;
        }
    }

    private static class ViewHolder {
        TextView gameBadge;
        ImageView icon;
        TextView pkg;
        Button rateBtn;
        TextView title;
        Switch toggle;
    }

    private View buildAppRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(dp(14), dp(8), dp(20), dp(8));
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackgroundColor(0);
        ImageView icon = new ImageView(this);
        LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(dp(34), dp(34));
        iconLp.setMargins(0, 0, dp(10), 0);
        icon.setLayoutParams(iconLp);
        row.addView(icon);
        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout nameRow = new LinearLayout(this);
        nameRow.setOrientation(LinearLayout.HORIZONTAL);
        nameRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setTextSize(2, 12f);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(-1);
        nameRow.addView(title);
        TextView badge = new TextView(this);
        badge.setText(getString(R.string.badge_game));
        badge.setTextSize(2, 8f);
        badge.setTypeface(Typeface.DEFAULT_BOLD);
        badge.setTextColor(-16715521);
        badge.setPadding(dp(4), dp(1), dp(4), dp(1));
        GradientDrawable badgeBg = new GradientDrawable();
        badgeBg.setColor(855699711);
        badgeBg.setCornerRadius(dp(4));
        badge.setBackground(badgeBg);
        LinearLayout.LayoutParams badgeLp = new LinearLayout.LayoutParams(-2, -2);
        badgeLp.setMargins(dp(6), 0, 0, 0);
        badge.setLayoutParams(badgeLp);
        nameRow.addView(badge);
        texts.addView(nameRow);
        TextView pkg = new TextView(this);
        pkg.setTextSize(2, 9.5f);
        pkg.setTextColor(ThemeManager.getSecondaryTextColor(this.currentTheme));
        texts.addView(pkg);
        row.addView(texts);
        Button rate = new Button(this);
        rate.setTextSize(2, 10f);
        rate.setTypeface(Typeface.DEFAULT_BOLD);
        rate.setTextColor(ThemeManager.getAccentColor(this.currentTheme));
        rate.setPadding(dp(6), dp(2), dp(6), dp(2));
        LinearLayout.LayoutParams rateLp = new LinearLayout.LayoutParams(-2, dp(28));
        rateLp.setMargins(0, 0, dp(6), 0);
        rate.setLayoutParams(rateLp);
        applyButtonPressFeedback(rate, 579387600, 1149812944, ThemeManager.getAccentColor(this.currentTheme), dp(6));
        row.addView(rate);
        Switch toggle = new Switch(this);
        LinearLayout.LayoutParams toggleLp = new LinearLayout.LayoutParams(-2, -2);
        toggleLp.setMargins(0, 0, dp(6), 0);
        toggle.setLayoutParams(toggleLp);
        row.addView(toggle);
        ViewHolder holder = new ViewHolder();
        holder.icon = icon;
        holder.title = title;
        holder.pkg = pkg;
        holder.gameBadge = badge;
        holder.rateBtn = rate;
        holder.toggle = toggle;
        row.setTag(holder);
        return row;
    }

    private void showRatePicker(View anchor, final AppInfo app) {
        PopupMenu menu = new PopupMenu(this, anchor);
        for (int i = 0; i < this.supportedRates.size(); i++) {
            int rate = this.supportedRates.get(i).intValue();
            menu.getMenu().add(0, rate, 0, getString(R.string.fmt_hz, Integer.valueOf(rate)));
        }
        menu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                final int rate = item.getItemId();
                app.targetHz = rate;
                prefs.edit().putInt("app_rate_" + app.packageName, rate).apply();
                if (appAdapter != null) {
                    appAdapter.notifyDataSetChanged();
                }
                RateLock.sExecutor.execute(new Runnable() {
                    @Override
                    public void run() {
                        boolean master = prefs.getBoolean("fps_enabled", false);
                        boolean watchdog = prefs.getBoolean("watchdog_mode", false);
                        if (master && watchdog && app.enabled) {
                            RateLock.recordPackageDiag(app.packageName, RateLock.hzToRateId(rate),
                                    RateLock.arm(MainActivity.this, app.packageName, RateLock.hzToRateId(rate)) ? 1 : 0,
                                    Oiface.registerGame(app.packageName));
                        }
                        uiHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                updateWatchdogStatusLine();
                            }
                        });
                    }
                });
                return true;
            }
        });
        menu.show();
    }

    private View createAboutView() {
        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
        LinearLayout column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        column.setPadding(dp(20), dp(20), dp(20), dp(28));
        column.setGravity(Gravity.CENTER_HORIZONTAL);
        LinearLayout card = createCard();
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(dp(20), dp(28), dp(20), dp(28));
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.ic_launcher);
        FrameLayout logoWrap = new FrameLayout(this);
        LinearLayout.LayoutParams wrapLp = new LinearLayout.LayoutParams(dp(108), dp(108));
        wrapLp.gravity = Gravity.CENTER_HORIZONTAL;
        wrapLp.setMargins(0, 0, 0, dp(14));
        logoWrap.setLayoutParams(wrapLp);
        FrameLayout.LayoutParams logoLp = new FrameLayout.LayoutParams(dp(72), dp(72), Gravity.CENTER);
        logo.setLayoutParams(logoLp);
        logoWrap.addView(logo);
        ShimmerRing ring = new ShimmerRing(this);
        ring.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        logoWrap.addView(ring);
        card.addView(logoWrap);
        TextView title = new TextView(this);
        title.setText(getString(R.string.app_name));
        title.setTextSize(2, 20f);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(-1);
        card.addView(title);
        TextView version = new TextView(this);
        version.setText(getString(R.string.about_version));
        version.setTextSize(2, 12f);
        version.setTextColor(ThemeManager.getSecondaryTextColor(this.currentTheme));
        version.setPadding(0, dp(4), 0, dp(18));
        card.addView(version);
        Button channel = new Button(this);
        channel.setText(getString(R.string.about_channel));
        channel.setTextSize(2, 11f);
        channel.setAllCaps(false);
        channel.setTypeface(Typeface.DEFAULT_BOLD);
        channel.setTextColor(-1);
        channel.setPadding(dp(20), dp(10), dp(20), dp(10));
        LinearLayout.LayoutParams channelLp = new LinearLayout.LayoutParams(-1, dp(44));
        channel.setLayoutParams(channelLp);
        applyButtonPressFeedback(channel, 872415231, 1442840575, ThemeManager.getAccentColor(this.currentTheme), dp(12));
        channel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/pipidistrtop")));
                } catch (Throwable ignored) {
                }
            }
        });
        card.addView(channel);
        Button github = new Button(this);
        github.setText(getString(R.string.about_github));
        github.setTextSize(2, 11f);
        github.setAllCaps(false);
        github.setTypeface(Typeface.DEFAULT_BOLD);
        github.setTextColor(-1);
        github.setPadding(dp(20), dp(10), dp(20), dp(10));
        LinearLayout.LayoutParams githubLp = new LinearLayout.LayoutParams(-1, dp(44));
        githubLp.setMargins(0, dp(8), 0, 0);
        github.setLayoutParams(githubLp);
        applyButtonPressFeedback(github, 872415231, 1442840575, ThemeManager.getAccentColor(this.currentTheme), dp(12));
        github.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/technofixte-debug/oppobbkhighhzunlocker")));
                } catch (Throwable ignored) {
                }
            }
        });
        card.addView(github);
        column.addView(card);
        scroll.addView(column);
        return scroll;
    }

    private void setThemeIndex(int index) {
        this.currentTheme = index;
        ThemeManager.setTheme(this, index);
        applyTheme();
        int tab = this.currentTab;
        this.currentTab = -1;
        if (this.contentContainer != null) {
            this.contentContainer.removeAllViews();
        }
        switchTab(tab);
        try {
            startService(new Intent(this, MainUnlockerOverlayService.class));
        } catch (Throwable ignored) {
        }
    }

    private void applyTheme() {
        if (this.rootFrame != null) {
            this.rootFrame.setBackgroundColor(ThemeManager.getBgColor(this.currentTheme));
        }
        if (this.ambientBg != null) {
            this.ambientBg.updateThemeColors(this.currentTheme);
        }
        if (this.bottomNav != null) {
            this.bottomNav.setBackgroundColor(ThemeManager.getNavColor(this.currentTheme));
        }
        if (this.bottomNavBorder != null) {
            this.bottomNavBorder.setBackgroundColor(ThemeManager.getNavBorder(this.currentTheme));
        }
        updateTabStyles();
        updateHeaderSubtitle();
        if (this.themeButton != null) {
            applyButtonPressFeedback(this.themeButton, 872415231, 1442840575, ThemeManager.getAccentColor(this.currentTheme), dp(10));
        }
        if (this.nebulaOverlay != null) {
            this.nebulaOverlay.updateTheme(this.currentTheme);
            this.nebulaOverlay.setNebulaEnabled(this.prefs.getBoolean("nebula_enabled", false));
        }
    }

    private LinearLayout createCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(ThemeManager.getCardColor(this.currentTheme));
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), ThemeManager.getCardStroke(this.currentTheme));
        card.setBackground(bg);
        card.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        return card;
    }

    private LinearLayout createToggleRow(String title, String hint, boolean checked,
            CompoundButton.OnCheckedChangeListener listener, Switch[] switchOut, TextView[] hintOut) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));
        TextView titleView = new TextView(this);
        titleView.setText(title);
        titleView.setTextSize(2, 12.5f);
        titleView.setTypeface(Typeface.DEFAULT_BOLD);
        titleView.setTextColor(-1);
        texts.addView(titleView);
        TextView hintView = new TextView(this);
        hintView.setText(hint);
        hintView.setTextSize(2, 10.5f);
        hintView.setTextColor(ThemeManager.getSecondaryTextColor(this.currentTheme));
        hintView.setPadding(0, dp(2), 0, 0);
        texts.addView(hintView);
        row.addView(texts);
        Switch sw = new Switch(this);
        sw.setChecked(checked);
        sw.jumpDrawablesToCurrentState();
        sw.setOnCheckedChangeListener(listener);
        row.addView(sw);
        if (switchOut != null) {
            switchOut[0] = sw;
        }
        if (hintOut != null) {
            hintOut[0] = hintView;
        }
        return row;
    }

    private void addDivider(LinearLayout parent) {
        View divider = new View(this);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, dp(1));
        params.setMargins(0, dp(10), 0, dp(10));
        divider.setLayoutParams(params);
        divider.setBackgroundColor(ThemeManager.getCardStroke(this.currentTheme));
        parent.addView(divider);
    }

    private void addVerticalSpace(LinearLayout parent, int dpSize) {
        View space = new View(this);
        space.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(dpSize)));
        parent.addView(space);
    }

    private void applyButtonPressFeedback(Button button, int normalColor, int strokeColor, int accent, int radius) {
        GradientDrawable normal = new GradientDrawable();
        normal.setColor(normalColor);
        normal.setCornerRadius(radius);
        normal.setStroke(dp(1), strokeColor);
        GradientDrawable pressed = new GradientDrawable();
        pressed.setColor((16777215 & accent) | 1291845632);
        pressed.setCornerRadius(radius);
        pressed.setStroke(dp(1.8f), accent);
        StateListDrawable states = new StateListDrawable();
        states.addState(new int[] {android.R.attr.state_pressed}, pressed);
        states.addState(new int[] {android.R.attr.state_focused}, pressed);
        states.addState(new int[0], normal);
        button.setBackground(states);
    }

    private void toggleOverlay(boolean enabled) {
        this.prefs.edit().putBoolean("overlay_enabled", enabled).apply();
        try {
            stopService(new Intent(this, FpsOverlayService.class));
        } catch (Throwable ignored) {
        }
        if (enabled) {
            if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
                try {
                    startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
                } catch (Throwable ignored) {
                }
                return;
            }
            startService(new Intent(this, MainUnlockerOverlayService.class));
            return;
        }
        if (this.prefs.getBoolean("fps_enabled", false)) {
            startService(new Intent(this, MainUnlockerOverlayService.class));
        } else {
            stopService(new Intent(this, MainUnlockerOverlayService.class));
        }
    }

    private void updateCurrentHzDisplay() {
        if (this.currentHzTextView != null) {
            this.currentHzTextView.setText(getString(R.string.fmt_hz, Integer.valueOf(getDisplayRefreshRate())));
        }
    }

    private int getDisplayRefreshRate() {
        try {
            return Math.round(getWindowManager().getDefaultDisplay().getRefreshRate());
        } catch (Throwable ignored) {
            return 120;
        }
    }

    private void hideKeyboard() {
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (imm == null) {
                return;
            }
            View focused = getCurrentFocus();
            if (focused == null) {
                focused = this.rootFrame;
            }
            if (focused != null && focused.getWindowToken() != null) {
                imm.hideSoftInputFromWindow(focused.getWindowToken(), 0);
            }
        } catch (Throwable ignored) {
        }
    }

    private int dp(float value) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, getResources().getDisplayMetrics()));
    }
}
