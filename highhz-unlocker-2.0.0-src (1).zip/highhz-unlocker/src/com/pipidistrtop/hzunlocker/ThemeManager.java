package com.pipidistrtop.hzunlocker;

import android.content.Context;

/* loaded from: classes.dex */
public class ThemeManager {
    public static final String PREF_THEME = "current_theme";
    public static final int THEME_AMOLED_BLACK = 3;
    public static final int THEME_CYBER_NEON = 0;
    public static final String[] THEME_NAMES = {"Cyber Neon", "Nord Slate", "OLED Dark Purple", "AMOLED Pure Black"};
    public static final int THEME_NORD_SLATE = 1;
    public static final int THEME_OLED_PURPLE = 2;

    public static int getTheme(Context context) {
        return context.getSharedPreferences("FpsPrefs", 0).getInt(PREF_THEME, 3);
    }

    public static void setTheme(Context context, int i) {
        context.getSharedPreferences("FpsPrefs", 0).edit().putInt(PREF_THEME, i).apply();
    }

    public static int getBgColor(int i) {
        switch (i) {
            case 1:
                return -15789028;
            case 2:
                return -15593447;
            case THEME_AMOLED_BLACK /* 3 */:
                return -16777216;
            default:
                return -16381422;
        }
    }

    public static int getCardColor(int i) {
        switch (i) {
            case 1:
                return -15327444;
            case 2:
                return -15001818;
            case THEME_AMOLED_BLACK /* 3 */:
                return -15592942;
            default:
                return -15984858;
        }
    }

    public static int getCardStroke(int i) {
        switch (i) {
            case 1:
                return -14405566;
            case 2:
                return -13752771;
            case THEME_AMOLED_BLACK /* 3 */:
                return -14277082;
            default:
                return -15322034;
        }
    }

    public static int getAccentColor(int i) {
        switch (i) {
            case 1:
                return -7814960;
            case 2:
                return -4809224;
            case THEME_AMOLED_BLACK /* 3 */:
                return -5005861;
            default:
                return -16715521;
        }
    }

    public static int getSecondaryTextColor(int i) {
        switch (i) {
            case 1:
                return -6970445;
            case 2:
                return -6449239;
            case THEME_AMOLED_BLACK /* 3 */:
                return -6710887;
            default:
                return -8609355;
        }
    }

    public static int getNavColor(int i) {
        switch (i) {
            case 1:
                return -15591390;
            case 2:
                return -15330529;
            case THEME_AMOLED_BLACK /* 3 */:
                return -16777216;
            default:
                return -16249576;
        }
    }

    public static int getNavBorder(int i) {
        switch (i) {
            case 1:
                return -14537670;
            case 2:
                return -13949640;
            case THEME_AMOLED_BLACK /* 3 */:
                return -14803426;
            default:
                return -15455426;
        }
    }
}
