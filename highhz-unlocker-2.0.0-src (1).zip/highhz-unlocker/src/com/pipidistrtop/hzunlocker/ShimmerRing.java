package com.pipidistrtop.hzunlocker;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.SweepGradient;
import android.util.TypedValue;
import android.view.View;

public class ShimmerRing extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Matrix matrix = new Matrix();
    private float angle;
    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!isAttachedToWindow()) {
                return;
            }
            angle = (angle + 3.6f) % 360f;
            invalidate();
            postDelayed(this, 32L);
        }
    };

    public ShimmerRing(Context context) {
        super(context);
        setWillNotDraw(false);
        this.paint.setStyle(Paint.Style.STROKE);
        this.paint.setStrokeWidth(dp(2.4f));
        this.paint.setStrokeCap(Paint.Cap.ROUND);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        removeCallbacks(this.tick);
        post(this.tick);
    }

    @Override
    protected void onDetachedFromWindow() {
        removeCallbacks(this.tick);
        super.onDetachedFromWindow();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f;
        float radius = Math.min(cx, cy) - this.paint.getStrokeWidth();
        if (radius <= 0f) {
            return;
        }
        int accent = ThemeManager.getAccentColor(ThemeManager.getTheme(getContext()));
        int rgb = accent & 0x00FFFFFF;
        SweepGradient shader = new SweepGradient(cx, cy,
                new int[] {
                        rgb | 0xFF000000,
                        rgb | 0xCC000000,
                        rgb | 0x44000000,
                        rgb,
                        rgb | 0xFF000000
                },
                new float[] {0f, 0.16f, 0.42f, 0.72f, 1f});
        this.matrix.setRotate(this.angle, cx, cy);
        shader.setLocalMatrix(this.matrix);
        this.paint.setShader(shader);
        canvas.drawCircle(cx, cy, radius, this.paint);
    }

    private float dp(float value) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, getResources().getDisplayMetrics());
    }
}
