package com.pipidistrtop.hzunlocker;

import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.IBinder;
import android.os.Parcel;
import android.provider.Settings;
import android.util.Log;
import android.view.Display;
import android.view.WindowManager;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/* loaded from: classes.dex */
public class RateLock {
    public static final int DEFAULT_VOTE_CODE = 12;
    public static final int MODE_CYCLE_1TO5 = 1;
    public static final int MODE_IDLE = 0;
    public static final int MODE_WATCHDOG = 2;
    private static final Set<String> NEVER_ARM;
    public static final String SERVICE_NAME = "oplusscreenmode";
    private static final String TAG = "RateLock";
    public static final String TOKEN = "com.oplus.screenmode.IOplusScreenMode";
    public static volatile int sArmedCount;
    public static final ExecutorService sExecutor;
    public static volatile long sLastCallTime;
    public static volatile int sLastHz;
    public static volatile String sLastPackage;
    public static volatile String sLastStatus;
    public static final Map<String, PackageDiag> sPackageDiags;
    public static volatile String sServiceAvailability;
    public static volatile boolean sOverlayServiceActive = false;
    public static volatile boolean sOverlayVisibleMode = false;
    public static volatile int sLastAppliedMode = -1;

    static {
        HashSet hashSet = new HashSet();
        hashSet.add("android");
        hashSet.add("com.android.systemui");
        NEVER_ARM = Collections.unmodifiableSet(hashSet);
        sPackageDiags = new ConcurrentHashMap();
        sArmedCount = 0;
        sLastStatus = "idle";
        sLastCallTime = 0L;
        sLastPackage = "";
        sLastHz = 0;
        sServiceAvailability = "checking";
        sExecutor = Executors.newSingleThreadExecutor();
    }

    public static class PackageDiag {

        /* renamed from: hz */
        public int f1hz;
        public boolean inVendorList;
        public String packageName;
        public int rateId;
        public int resCode;
        public long timestamp = System.currentTimeMillis();

        public PackageDiag(String str, int i, int i2, int i3, boolean z) {
            this.packageName = str;
            this.rateId = i;
            this.f1hz = i2;
            this.resCode = i3;
            this.inVendorList = z;
        }
    }

    public static int hzToRateId(int i) {
        switch (i) {
            case 60:
                return 2;
            case 90:
                return 1;
            case 120:
            default:
                return 3;
            case 144:
                return 4;
            case 165:
                return 7;
        }
    }

    public static int rateIdToHz(int i) {
        switch (i) {
            case 1:
                return 90;
            case 2:
                return 60;
            case ThemeManager.THEME_AMOLED_BLACK /* 3 */:
                return 120;
            case 4:
                return 144;
            case 5:
            case 6:
            default:
                return 0;
            case 7:
                return 165;
        }
    }

    public static List<Integer> getSupportedRefreshRates(Context context) {
        Display.Mode[] supportedModes;
        ArrayList arrayList = new ArrayList();
        if (context != null) {
            try {
                WindowManager windowManager = (WindowManager) context.getSystemService("window");
                if (windowManager != null) {
                    Display defaultDisplay = windowManager.getDefaultDisplay();
                    if (Build.VERSION.SDK_INT >= 23 && defaultDisplay != null && (supportedModes = defaultDisplay.getSupportedModes()) != null) {
                        for (Display.Mode mode : supportedModes) {
                            int round = Math.round(mode.getRefreshRate());
                            if (round > 30 && !arrayList.contains(Integer.valueOf(round))) {
                                arrayList.add(Integer.valueOf(round));
                            }
                        }
                    }
                }
            } catch (Throwable th) {
            }
        }
        if (arrayList.isEmpty()) {
            arrayList.add(60);
            arrayList.add(90);
            arrayList.add(120);
        }
        Collections.sort(arrayList);
        return arrayList;
    }

    public static int getMaxSupportedRefreshRate(Context context) {
        List<Integer> rates = getSupportedRefreshRates(context);
        return rates.get(rates.size() - 1).intValue();
    }

    public static int getAppRate(SharedPreferences sharedPreferences, Context context, String str) {
        List<Integer> supportedRefreshRates = getSupportedRefreshRates(context);
        int intValue = supportedRefreshRates.get(supportedRefreshRates.size() - 1).intValue();
        if (sharedPreferences != null && str != null && !str.isEmpty()) {
            String str2 = "app_rate_" + str;
            if (sharedPreferences.contains(str2)) {
                int i = sharedPreferences.getInt(str2, intValue);
                if (supportedRefreshRates.contains(Integer.valueOf(i))) {
                    return i;
                }
                int intValue2 = supportedRefreshRates.get(0).intValue();
                Iterator<Integer> it = supportedRefreshRates.iterator();
                while (true) {
                    int i2 = intValue2;
                    if (it.hasNext()) {
                        intValue2 = it.next().intValue();
                        if (intValue2 > i) {
                            intValue2 = i2;
                        }
                    } else {
                        return i2;
                    }
                }
            } else {
                return intValue;
            }
        } else {
            return intValue;
        }
    }

    public static void recordPackageDiag(String str, int i, int i2, boolean z) {
        sPackageDiags.put(str, new PackageDiag(str, i, rateIdToHz(i), i2, z));
    }

    public static void removePackageDiag(String str) {
        sPackageDiags.remove(str);
    }

    public static List<PackageDiag> getPackageDiagList() {
        return new ArrayList(sPackageDiags.values());
    }

    public static boolean arm(Context context, String str, int i) {
        int i2;
        int i3;
        IBinder iBinder = null;
        if (str == null || str.isEmpty() || (NEVER_ARM.contains(str) && i > 0)) {
            return false;
        }
        try {
            iBinder = (IBinder) Class.forName("android.os.ServiceManager").getMethod("getService", String.class).invoke(null, SERVICE_NAME);
        } catch (Throwable th) {
        }
        if (iBinder == null) {
            sServiceAvailability = "oplusscreenmode unavailable";
            sLastStatus = "service unavailable";
            sLastCallTime = System.currentTimeMillis();
            return false;
        }
        sServiceAvailability = "oplusscreenmode active";
        try {
            Field declaredField = Class.forName("com.oplus.screenmode.IOplusScreenMode$Stub").getDeclaredField("TRANSACTION_requestGameRefreshRate");
            declaredField.setAccessible(true);
            i2 = declaredField.getInt(null);
        } catch (Throwable th2) {
            i2 = 12;
        }
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        try {
            try {
                obtain.writeInterfaceToken(TOKEN);
                obtain.writeString(str);
                obtain.writeInt(i);
                iBinder.transact(i2, obtain, obtain2, 0);
                obtain2.readException();
                i3 = obtain2.readInt();
            } finally {
                obtain.recycle();
                obtain2.recycle();
            }
        } catch (Throwable th3) {
            sLastStatus = "binder error: " + th3.getMessage();
            Log.e(TAG, "arm error: " + th3.getMessage());
            obtain.recycle();
            obtain2.recycle();
            i3 = -1;
        }
        SharedPreferences.Editor edit = context.getSharedPreferences("FpsPrefs", 0).edit();
        if (i > 0 && i3 == 1) {
            edit.putInt("armed_" + str, i);
        } else if (i == 0) {
            edit.remove("armed_" + str);
        }
        edit.apply();
        sLastCallTime = System.currentTimeMillis();
        sLastPackage = str;
        sLastHz = rateIdToHz(i);
        if (i3 == 1) {
            sLastStatus = i == 0 ? "vote cleared" : sLastHz + " Hz (code 1)";
        } else if (i3 != -1) {
            sLastStatus = "code: " + i3;
        }
        sArmedCount = getArmedMap(context).size();
        return i3 == 1;
    }

    public static boolean release(Context context, String str) {
        return arm(context, str, 0);
    }

    public static Map<String, Integer> getArmedMap(Context context) {
        HashMap hashMap = new HashMap();
        for (Map.Entry<String, ?> entry : context.getSharedPreferences("FpsPrefs", 0).getAll().entrySet()) {
            String key = entry.getKey();
            if (key != null && key.startsWith("armed_")) {
                String substring = key.substring("armed_".length());
                Object value = entry.getValue();
                if (value instanceof Integer) {
                    hashMap.put(substring, (Integer) value);
                }
            }
        }
        return hashMap;
    }

    public static void releaseAll(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences("FpsPrefs", 0);
        HashSet<String> hashSet = new HashSet();
        hashSet.addAll(getArmedMap(context).keySet());
        Map<String, ?> all = sharedPreferences.getAll();
        for (String str : all.keySet()) {
            if (str != null && str.startsWith("app_hz_")) {
                hashSet.add(str.substring("app_hz_".length()));
            }
        }
        for (String str2 : hashSet) {
            arm(context, str2, 0);
            Oiface.unregisterGame(str2);
        }
        SharedPreferences.Editor edit = sharedPreferences.edit();
        for (String str3 : all.keySet()) {
            if (str3 != null && str3.startsWith("armed_")) {
                edit.remove(str3);
            }
        }
        edit.apply();
        sPackageDiags.clear();
        sArmedCount = 0;
    }

    public static void applyState(final Context context) {
        if (context != null) {
            sExecutor.execute(new Runnable() { // from class: com.pipidistrtop.hzunlocker.RateLock.1
                @Override // java.lang.Runnable
                public void run() {
                    int i = 0;
                    try {
                        SharedPreferences sharedPreferences = context.getSharedPreferences("FpsPrefs", 0);
                        boolean master = sharedPreferences.getBoolean("fps_enabled", false);
                        boolean watchdog = sharedPreferences.getBoolean("watchdog_mode", false);
                        boolean overlay = sharedPreferences.getBoolean("overlay_enabled", false);
                        ContentResolver contentResolver = context.getContentResolver();
                        if (master) {
                            i = !watchdog ? MODE_CYCLE_1TO5 : MODE_WATCHDOG;
                        }
                        try {
                            context.stopService(new Intent(context, FpsOverlayService.class));
                        } catch (Throwable ignored) {
                        }
                        if (i == MODE_IDLE) {
                            try {
                                FpsService.cancelRestart(context);
                                context.stopService(new Intent(context, FpsService.class));
                            } catch (Throwable ignored) {
                            }
                            try {
                                context.stopService(new Intent(context, WatchdogService.class));
                            } catch (Throwable ignored) {
                            }
                            RateLock.releaseAll(context);
                            Oiface.unregisterAllOurGames();
                            if (RateLock.sLastAppliedMode != MODE_IDLE) {
                                RateLock.restorePeakRate(contentResolver);
                            }
                        } else if (i == MODE_CYCLE_1TO5) {
                            try {
                                context.stopService(new Intent(context, WatchdogService.class));
                            } catch (Throwable ignored) {
                            }
                            RateLock.releaseAll(context);
                            Oiface.unregisterAllOurGames();
                            try {
                                Intent fpsIntent = new Intent(context, FpsService.class);
                                if (Build.VERSION.SDK_INT >= 26) {
                                    context.startForegroundService(fpsIntent);
                                } else {
                                    context.startService(fpsIntent);
                                }
                            } catch (Throwable ignored) {
                            }
                        } else {
                            try {
                                FpsService.cancelRestart(context);
                                context.stopService(new Intent(context, FpsService.class));
                            } catch (Throwable ignored) {
                            }
                            if (RateLock.sLastAppliedMode == MODE_CYCLE_1TO5 || RateLock.sLastAppliedMode == -1) {
                                RateLock.restorePeakRate(contentResolver);
                            }
                            Intent intent = new Intent(context, WatchdogService.class);
                            try {
                                if (Build.VERSION.SDK_INT >= 26) {
                                    context.startForegroundService(intent);
                                } else {
                                    context.startService(intent);
                                }
                            } catch (Throwable ignored) {
                            }
                        }
                        try {
                            if (master || overlay) {
                                context.startService(new Intent(context, MainUnlockerOverlayService.class));
                            } else {
                                context.stopService(new Intent(context, MainUnlockerOverlayService.class));
                            }
                        } catch (Throwable ignored) {
                        }
                        RateLock.sLastAppliedMode = i;
                        RateLock.sArmedCount = RateLock.getArmedMap(context).size();
                    } catch (Throwable th9) {
                        Log.e(RateLock.TAG, "applyState error: " + th9.getMessage());
                    }
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void restorePeakRate(ContentResolver contentResolver) {
        if (contentResolver != null) {
            try {
                Settings.System.putString(contentResolver, "peak_refresh_rate", "120.00001");
            } catch (Throwable th) {
            }
        }
    }
}
