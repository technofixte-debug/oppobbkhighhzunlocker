package com.pipidistrtop.hzunlocker;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

/**
 * Retired. The visible counter and the hidden unlocker window are both
 * {@link MainUnlockerOverlayService}, so this service never adds a second view.
 */
public class FpsOverlayService extends Service {
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        stopSelf();
        return START_NOT_STICKY;
    }
}
