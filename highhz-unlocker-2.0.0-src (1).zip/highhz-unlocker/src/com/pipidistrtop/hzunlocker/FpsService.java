package com.pipidistrtop.hzunlocker;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.util.Log;

public class FpsService extends Service {
    private static final String CHANNEL_ID = "FpsServiceChannel";
    private static final int RESTART_REQUEST = 7;
    private static final long HEARTBEAT_MS = 15000L;
    private static final String TAG = "FpsService";
    private volatile boolean isRunning = false;
    private Thread worker;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    public static boolean shouldWrite(Context context) {
        SharedPreferences prefs = context.getSharedPreferences("FpsPrefs", 0);
        return prefs.getBoolean("fps_enabled", false) && !prefs.getBoolean("watchdog_mode", false);
    }

    public static void scheduleRestart(Context context, long delayMs) {
        try {
            AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (alarmManager == null) {
                return;
            }
            long when = System.currentTimeMillis() + delayMs;
            PendingIntent pending = restartIntent(context);
            try {
                if (Build.VERSION.SDK_INT >= 23) {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pending);
                } else if (Build.VERSION.SDK_INT >= 19) {
                    alarmManager.setExact(AlarmManager.RTC_WAKEUP, when, pending);
                } else {
                    alarmManager.set(AlarmManager.RTC_WAKEUP, when, pending);
                }
            } catch (Throwable ignored) {
                alarmManager.set(AlarmManager.RTC_WAKEUP, when, pending);
            }
        } catch (Throwable ignored) {
        }
    }

    public static void cancelRestart(Context context) {
        try {
            AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (alarmManager != null) {
                alarmManager.cancel(restartIntent(context));
            }
        } catch (Throwable ignored) {
        }
    }

    private static PendingIntent restartIntent(Context context) {
        Intent intent = new Intent(context, FpsService.class);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        return PendingIntent.getService(context, RESTART_REQUEST, intent, flags);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (!shouldWrite(this)) {
            cancelRestart(this);
            isRunning = false;
            stopSelf();
            return START_NOT_STICKY;
        }
        startForegroundServiceNotification();
        if (!this.isRunning) {
            this.isRunning = true;
            this.worker = new Thread(new Runnable() {
                @Override
                public void run() {
                    while (FpsService.this.isRunning) {
                        if (!FpsService.shouldWrite(FpsService.this)) {
                            FpsService.this.isRunning = false;
                            FpsService.cancelRestart(FpsService.this);
                            FpsService.this.stopSelf();
                            return;
                        }
                        FpsService.writeSequence1to5(FpsService.this.getContentResolver());
                        try {
                            Thread.sleep(FpsService.this.getInterval());
                        } catch (InterruptedException ignored) {
                            return;
                        }
                    }
                }
            }, "fps-writer");
            this.worker.start();
        }
        scheduleRestart(this, HEARTBEAT_MS);
        return START_STICKY;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        if (shouldWrite(this)) {
            scheduleRestart(this, 1000L);
        } else {
            cancelRestart(this);
        }
    }

    private int getInterval() {
        return getSharedPreferences("FpsPrefs", 0).getInt("watchdog_interval", 1000);
    }

    public static void writeSequence1to5(ContentResolver contentResolver) {
        if (contentResolver != null) {
            for (int i = 1; i <= 5; i++) {
                try {
                    Settings.System.putString(contentResolver, "peak_refresh_rate", String.valueOf(i));
                    try {
                        Thread.sleep(12L);
                    } catch (InterruptedException ignored) {
                    }
                } catch (Exception e2) {
                    Log.e(TAG, "Error writing 1..5 sequence: " + e2.getMessage());
                    return;
                }
            }
        }
    }

    public static void restoreDefaultHz(ContentResolver contentResolver) {
        if (contentResolver != null) {
            try {
                Settings.System.putString(contentResolver, "peak_refresh_rate", "120.00001");
            } catch (Exception e) {
                Log.e(TAG, "Error restoring default refresh rate: " + e.getMessage());
            }
        }
    }

    private void startForegroundServiceNotification() {
        if (Build.VERSION.SDK_INT >= 26) {
            try {
                Notify.ensureChannel(this, CHANNEL_ID, getString(R.string.channel_fps));
                Notification notification = new Notification.Builder(this, CHANNEL_ID)
                        .setContentTitle(getString(R.string.app_name))
                        .setContentText(getString(R.string.notif_fps))
                        .setSmallIcon(R.drawable.ic_launcher)
                        .setContentIntent(PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), 67108864))
                        .build();
                startForeground(101, notification);
            } catch (Exception ignored) {
            }
        }
    }

    @Override
    public void onDestroy() {
        this.isRunning = false;
        if (this.worker != null) {
            this.worker.interrupt();
        }
        if (shouldWrite(this)) {
            scheduleRestart(this, 1000L);
        }
        super.onDestroy();
    }
}
