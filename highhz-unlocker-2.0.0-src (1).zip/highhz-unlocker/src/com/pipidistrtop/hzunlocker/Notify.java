package com.pipidistrtop.hzunlocker;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;

public final class Notify {
    /** Used only when the channel does not exist yet. Existing channels are not modified. */
    public static final int NEW_CHANNEL_IMPORTANCE = NotificationManager.IMPORTANCE_NONE;

    private Notify() {
    }

    public static void ensureChannel(Context context, String channelId, String name) {
        if (context == null || Build.VERSION.SDK_INT < 26) {
            return;
        }
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) {
            return;
        }
        if (manager.getNotificationChannel(channelId) != null) {
            return;
        }
        manager.createNotificationChannel(new NotificationChannel(channelId, name, NEW_CHANNEL_IMPORTANCE));
    }
}
